"""
Database Models - All Tables
SQLAlchemy ORM Models for Tahakikat Platform
"""

from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, ForeignKey, Enum, DECIMAL, Date, JSON
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum

from app.database import Base

# Enums
class UserRole(str, enum.Enum):
    INVESTIGATOR = "Investigator"
    RCU_REVIEWER = "RCU_Reviewer"
    COMPLIANCE_OFFICER = "Compliance_Officer"
    CRO = "CRO"
    INTERNAL_AUDIT = "Internal_Audit"
    BOARD = "Board"

class CaseType(str, enum.Enum):
    EMPLOYEE_FRAUD = "Employee_Fraud"
    VENDOR_FRAUD = "Vendor_Fraud"
    EMPLOYEE_MISCONDUCT = "Employee_Misconduct"

class CaseStatus(str, enum.Enum):
    DRAFT = "Draft"
    INVESTIGATION = "Investigation"
    RCU_REVIEW = "RCU_Review"
    COMPLIANCE_DECISION = "Compliance_Decision"
    CLOSED = "Closed"

class Severity(str, enum.Enum):
    S1 = "S1"
    S2 = "S2"
    S3 = "S3"
    S4 = "S4"

class EvidenceStrength(str, enum.Enum):
    DOCUMENTARY = "Documentary"
    TESTIMONIAL = "Testimonial"
    BOTH = "Both"
    WEAK = "Weak"

# Models

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(50), nullable=False, index=True)
    department = Column(String(100))
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    created_cases = relationship("Case", foreign_keys="Case.created_by", back_populates="creator")
    assigned_cases = relationship("Case", foreign_keys="Case.assigned_to", back_populates="assignee")


class Case(Base):
    __tablename__ = "cases"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_number = Column(String(50), unique=True, nullable=False, index=True)
    case_type = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False, index=True, default="Draft")
    severity = Column(String(10), nullable=False, index=True)
    
    # Subject Details
    subject_name = Column(String(255), nullable=False)
    subject_type = Column(String(50), nullable=False)
    subject_employee_id = Column(String(100))
    subject_department = Column(String(100))
    subject_designation = Column(String(100))
    
    # Case Details
    allegation_summary = Column(Text, nullable=False)
    amount_involved = Column(DECIMAL(15, 2))
    currency = Column(String(10), default="INR")
    incident_date = Column(Date)
    detection_date = Column(Date, nullable=False, index=True)
    reporting_date = Column(Date)
    
    # Classification
    fraud_nature = Column(String(100))
    perpetrator_type = Column(String(50))
    modus_operandi = Column(Text)
    evidence_strength = Column(String(50))
    impact_type = Column(String(100))
    
    # Metadata
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    assigned_to = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    closed_at = Column(DateTime(timezone=True))
    closed_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    closure_reason = Column(Text)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    creator = relationship("User", foreign_keys=[created_by], back_populates="created_cases")
    assignee = relationship("User", foreign_keys=[assigned_to], back_populates="assigned_cases")
    evidence = relationship("Evidence", back_populates="case", cascade="all, delete-orphan")
    findings = relationship("Finding", back_populates="case", cascade="all, delete-orphan")
    interviews = relationship("Interview", back_populates="case", cascade="all, delete-orphan")
    reviews = relationship("RCUReview", back_populates="case", cascade="all, delete-orphan")
    decisions = relationship("ComplianceDecision", back_populates="case", cascade="all, delete-orphan")
    rbi_reports = relationship("RBIReport", back_populates="case", cascade="all, delete-orphan")


class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    evidence_number = Column(String(50), nullable=False)
    
    # Evidence Details
    evidence_type = Column(String(100), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    source = Column(String(255))
    collection_date = Column(Date, nullable=False)
    collection_method = Column(String(100))
    
    # File Details
    file_path = Column(String(500))
    file_name = Column(String(255))
    file_size_bytes = Column(Integer)
    file_hash = Column(String(64))  # SHA-256
    
    # Classification
    relevance = Column(String(50))
    authenticity_verified = Column(Boolean, default=False)
    chain_of_custody_notes = Column(Text)
    
    # Metadata
    uploaded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    case = relationship("Case", back_populates="evidence")
    finding_links = relationship("EvidenceFindingLink", back_populates="evidence", cascade="all, delete-orphan")


class Finding(Base):
    __tablename__ = "findings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    finding_number = Column(String(50), nullable=False)
    
    category = Column(String(100), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    facts_established = Column(Text, nullable=False)
    inference = Column(Text)
    risk_rating = Column(String(50))
    
    # Red Flags
    is_red_flag = Column(Boolean, default=False, index=True)
    red_flag_details = Column(Text)
    
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    case = relationship("Case", back_populates="findings")
    evidence_links = relationship("EvidenceFindingLink", back_populates="finding", cascade="all, delete-orphan")


class EvidenceFindingLink(Base):
    __tablename__ = "evidence_finding_links"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    evidence_id = Column(UUID(as_uuid=True), ForeignKey("evidence.id", ondelete="CASCADE"), nullable=False, index=True)
    finding_id = Column(UUID(as_uuid=True), ForeignKey("findings.id", ondelete="CASCADE"), nullable=False, index=True)
    relevance_note = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    evidence = relationship("Evidence", back_populates="finding_links")
    finding = relationship("Finding", back_populates="evidence_links")


class Interview(Base):
    __tablename__ = "interviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    interview_number = Column(String(50), nullable=False)
    
    # Interviewee Details
    interviewee_name = Column(String(255), nullable=False)
    interviewee_role = Column(String(100))
    interviewee_department = Column(String(100))
    relationship_to_case = Column(String(100))
    
    # Interview Details
    interview_date = Column(Date, nullable=False, index=True)
    interview_mode = Column(String(50))
    conducted_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    location = Column(String(255))
    duration_minutes = Column(Integer)
    
    # Content
    statement_summary = Column(Text, nullable=False)
    key_admissions = Column(Text)
    management_explanation = Column(Text)
    is_contradictory = Column(Boolean, default=False)
    contradicts_note = Column(Text)
    
    # Recording
    recording_available = Column(Boolean, default=False)
    recording_file_path = Column(String(500))
    transcript_file_path = Column(String(500))
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    case = relationship("Case", back_populates="interviews")


class RCUReview(Base):
    __tablename__ = "rcu_reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    
    reviewer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    review_date = Column(Date, nullable=False)
    
    # Review Assessment
    findings_validated = Column(Boolean)
    evidence_adequate = Column(Boolean)
    investigation_complete = Column(Boolean)
    
    recommendation = Column(String(100), nullable=False)
    recommendation_rationale = Column(Text, nullable=False)
    
    additional_comments = Column(Text)
    escalated_to_cro = Column(Boolean, default=False)
    escalation_reason = Column(Text)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    case = relationship("Case", back_populates="reviews")


class ComplianceDecision(Base):
    __tablename__ = "compliance_decisions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Decision Authority
    decided_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    decision_date = Column(Date, nullable=False)
    
    # System Suggestion
    system_suggested_reportable = Column(Boolean)
    system_suggestion_rationale = Column(Text)
    
    # Actual Decision
    is_reportable_to_rbi = Column(Boolean, nullable=False)
    decision_rationale = Column(Text, nullable=False)
    
    # Override Tracking
    is_override = Column(Boolean, default=False, index=True)
    override_justification = Column(Text)
    override_visible_to = Column(String(50))
    
    # S4 Special Handling
    requires_cro_approval = Column(Boolean, default=False)
    cro_approved = Column(Boolean)
    cro_approval_date = Column(Date)
    cro_approval_notes = Column(Text)
    ceo_notified = Column(Boolean, default=False)
    ceo_notification_date = Column(Date)
    
    # Classification
    fraud_classification = Column(String(100))
    amount_bucket = Column(String(50))
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    case = relationship("Case", back_populates="decisions")


class RBIReport(Base):
    __tablename__ = "rbi_reports"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    
    report_type = Column(String(10), nullable=False, index=True)  # FMR-1, FMR-2, FMR-3
    report_date = Column(Date, nullable=False)
    
    # Timeline Tracking
    due_date = Column(Date, nullable=False, index=True)
    submitted_date = Column(Date)
    is_delayed = Column(Boolean, default=False)
    delay_reason = Column(Text)
    
    # Report Content
    report_data = Column(JSONB, nullable=False)
    
    # Reclassification Tracking
    original_classification = Column(String(100))
    reclassified_to = Column(String(100))
    reclassification_date = Column(Date)
    reclassification_reason = Column(Text)
    
    # Submission
    submitted_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    submission_reference = Column(String(100))
    
    # Document
    report_file_path = Column(String(500))
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    case = relationship("Case", back_populates="rbi_reports")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Event Details
    entity_type = Column(String(50), nullable=False, index=True)
    entity_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    action = Column(String(50), nullable=False)
    
    # User Context
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), index=True)
    user_role = Column(String(50))
    user_ip = Column(String(45))
    
    # Change Tracking
    changes = Column(JSONB)
    reason = Column(Text)
    
    # Metadata
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)


class ReportTemplate(Base):
    __tablename__ = "report_templates"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    template_name = Column(String(255), nullable=False)
    template_type = Column(String(50), nullable=False, index=True)
    
    # Template Content
    structure = Column(JSONB, nullable=False)
    tone_rules = Column(JSONB)
    language_safeguards = Column(JSONB)
    
    is_active = Column(Boolean, default=True, index=True)
    version = Column(Integer, default=1)
    
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
