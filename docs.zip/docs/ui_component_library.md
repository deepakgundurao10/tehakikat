# Tahakikat - UI Component Library Specification
## Reusable Components for Investigation Platform

---

## TABLE OF CONTENTS

1. [Component Architecture](#1-component-architecture)
2. [Base Components](#2-base-components)
3. [Form Components](#3-form-components)
4. [Data Display Components](#4-data-display-components)
5. [Navigation Components](#5-navigation-components)
6. [Feedback Components](#6-feedback-components)
7. [Domain-Specific Components](#7-domain-specific-components)
8. [Layout Components](#8-layout-components)
9. [Code Examples](#9-code-examples)

---

## 1. COMPONENT ARCHITECTURE

### 1.1 Component Organization

```
src/
├── components/
│   ├── base/               # Atomic components
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   ├── Badge.tsx
│   │   └── ...
│   ├── forms/              # Form-specific components
│   │   ├── FormInput.tsx
│   │   ├── FormSelect.tsx
│   │   └── ...
│   ├── data-display/       # Tables, cards, etc.
│   │   ├── DataTable.tsx
│   │   ├── Card.tsx
│   │   └── ...
│   ├── feedback/           # Alerts, toasts, etc.
│   │   ├── Alert.tsx
│   │   ├── Toast.tsx
│   │   └── ...
│   ├── navigation/         # Navbar, sidebar, etc.
│   │   ├── Sidebar.tsx
│   │   ├── Breadcrumbs.tsx
│   │   └── ...
│   ├── layout/             # Page layouts
│   │   ├── DashboardLayout.tsx
│   │   ├── PageHeader.tsx
│   │   └── ...
│   └── domain/             # Business-specific
│       ├── CaseCard.tsx
│       ├── EvidenceViewer.tsx
│       ├── FindingForm.tsx
│       └── ...
└── hooks/                  # Custom React hooks
    ├── useCase.ts
    ├── useEvidence.ts
    └── ...
```

### 1.2 Design Principles

**Atomic Design Philosophy:**
- **Atoms:** Basic elements (Button, Input, Badge)
- **Molecules:** Combinations of atoms (FormInput = Label + Input + Error)
- **Organisms:** Complex UI sections (CaseCard, EvidenceTable)
- **Templates:** Page layouts
- **Pages:** Specific instances with real data

**Component Best Practices:**
- Single Responsibility Principle
- Composition over inheritance
- Props over state when possible
- TypeScript for type safety
- Storybook for component documentation

---

## 2. BASE COMPONENTS

### 2.1 Button Component

**Variants:** Primary, Secondary, Danger, Ghost, Link

```typescript
// components/base/Button.tsx

import { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-primary-700 text-white hover:bg-primary-800",
        secondary: "bg-gray-200 text-gray-900 hover:bg-gray-300",
        danger: "bg-danger text-white hover:bg-red-600",
        ghost: "hover:bg-gray-100 text-gray-700",
        link: "text-primary-700 underline-offset-4 hover:underline"
      },
      size: {
        sm: "h-9 px-3 text-sm",
        md: "h-10 px-4 py-2",
        lg: "h-11 px-8 text-lg"
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "md"
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  isLoading?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, isLoading, children, ...props }, ref) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        disabled={isLoading || props.disabled}
        {...props}
      >
        {isLoading && (
          <svg className="mr-2 h-4 w-4 animate-spin" viewBox="0 0 24 24">
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
              fill="none"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        )}
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";

export { Button, buttonVariants };
```

**Usage:**
```tsx
<Button>Primary Button</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="danger" size="lg">Delete</Button>
<Button isLoading>Saving...</Button>
```

### 2.2 Badge Component

**Variants:** Status, Severity, Priority

```typescript
// components/base/Badge.tsx

import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors",
  {
    variants: {
      variant: {
        // Status variants
        draft: "bg-gray-100 text-gray-800",
        investigation: "bg-blue-100 text-blue-800",
        review: "bg-yellow-100 text-yellow-800",
        closed: "bg-green-100 text-green-800",
        
        // Severity variants
        s1: "bg-red-100 text-red-800 border border-red-200",
        s2: "bg-orange-100 text-orange-800 border border-orange-200",
        s3: "bg-blue-100 text-blue-800 border border-blue-200",
        s4: "bg-gray-100 text-gray-800 border border-gray-200",
        
        // General variants
        success: "bg-green-100 text-green-800",
        warning: "bg-yellow-100 text-yellow-800",
        danger: "bg-red-100 text-red-800",
        info: "bg-blue-100 text-blue-800"
      }
    },
    defaultVariants: {
      variant: "info"
    }
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {
  icon?: React.ReactNode;
}

function Badge({ className, variant, icon, children, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props}>
      {icon && <span className="mr-1">{icon}</span>}
      {children}
    </div>
  );
}

export { Badge, badgeVariants };
```

**Usage:**
```tsx
<Badge variant="s3">S3 - Medium</Badge>
<Badge variant="investigation">In Progress</Badge>
<Badge variant="danger" icon={<AlertIcon />}>Critical</Badge>
```

### 2.3 Input Component

```typescript
// components/base/Input.tsx

import { forwardRef } from 'react';
import { cn } from '@/lib/utils';

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: string;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, error, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
          error && "border-danger focus-visible:ring-danger",
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);

Input.displayName = "Input";

export { Input };
```

### 2.4 Select Component

```typescript
// components/base/Select.tsx

import { forwardRef } from 'react';
import { cn } from '@/lib/utils';
import { ChevronDownIcon } from 'lucide-react';

export interface SelectProps
  extends React.SelectHTMLAttributes<HTMLSelectElement> {
  error?: string;
  options: Array<{ value: string; label: string }>;
}

const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, error, options, ...props }, ref) => {
    return (
      <div className="relative">
        <select
          className={cn(
            "flex h-10 w-full appearance-none rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
            error && "border-danger focus-visible:ring-danger",
            className
          )}
          ref={ref}
          {...props}
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDownIcon className="absolute right-3 top-3 h-4 w-4 text-gray-500 pointer-events-none" />
      </div>
    );
  }
);

Select.displayName = "Select";

export { Select };
```

---

## 3. FORM COMPONENTS

### 3.1 FormField Component

**Combines Label, Input/Select, Error Message**

```typescript
// components/forms/FormField.tsx

import { Label } from '@/components/base/Label';
import { Input, InputProps } from '@/components/base/Input';
import { Select, SelectProps } from '@/components/base/Select';
import { Textarea, TextareaProps } from '@/components/base/Textarea';

type FormFieldType = 'input' | 'select' | 'textarea';

interface BaseFormFieldProps {
  id: string;
  label: string;
  error?: string;
  required?: boolean;
  helpText?: string;
}

type FormFieldProps = BaseFormFieldProps & (
  | ({ type?: 'input' } & InputProps)
  | ({ type: 'select' } & SelectProps)
  | ({ type: 'textarea' } & TextareaProps)
);

export function FormField({
  id,
  label,
  error,
  required,
  helpText,
  type = 'input',
  ...inputProps
}: FormFieldProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>
        {label}
        {required && <span className="text-danger ml-1">*</span>}
      </Label>
      
      {type === 'input' && (
        <Input id={id} error={error} {...(inputProps as InputProps)} />
      )}
      
      {type === 'select' && (
        <Select id={id} error={error} {...(inputProps as SelectProps)} />
      )}
      
      {type === 'textarea' && (
        <Textarea id={id} error={error} {...(inputProps as TextareaProps)} />
      )}
      
      {helpText && !error && (
        <p className="text-sm text-gray-500">{helpText}</p>
      )}
      
      {error && (
        <p className="text-sm text-danger">{error}</p>
      )}
    </div>
  );
}
```

**Usage:**
```tsx
<FormField
  id="subject_name"
  label="Subject Name"
  required
  error={errors.subject_name}
  placeholder="Enter subject name"
/>

<FormField
  id="severity"
  label="Severity"
  type="select"
  required
  options={[
    { value: 'S1', label: 'S1 - Critical' },
    { value: 'S2', label: 'S2 - High' },
    { value: 'S3', label: 'S3 - Medium' },
    { value: 'S4', label: 'S4 - Low' }
  ]}
/>
```

### 3.2 FileUpload Component

```typescript
// components/forms/FileUpload.tsx

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { UploadIcon, FileIcon, XIcon } from 'lucide-react';
import { Button } from '@/components/base/Button';
import { cn } from '@/lib/utils';

interface FileUploadProps {
  onUpload: (files: File[]) => void;
  maxFiles?: number;
  maxSize?: number; // in MB
  acceptedFileTypes?: string[];
  error?: string;
}

export function FileUpload({
  onUpload,
  maxFiles = 10,
  maxSize = 50,
  acceptedFileTypes = ['application/pdf', 'image/*', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  error
}: FileUploadProps) {
  const [files, setFiles] = useState<File[]>([]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(prev => [...prev, ...acceptedFiles]);
    onUpload(acceptedFiles);
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxFiles,
    maxSize: maxSize * 1024 * 1024,
    accept: acceptedFileTypes.reduce((acc, type) => ({ ...acc, [type]: [] }), {})
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={cn(
          "border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors",
          isDragActive ? "border-primary-500 bg-primary-50" : "border-gray-300 hover:border-gray-400",
          error && "border-danger"
        )}
      >
        <input {...getInputProps()} />
        <UploadIcon className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        {isDragActive ? (
          <p className="text-sm text-gray-600">Drop files here...</p>
        ) : (
          <>
            <p className="text-sm text-gray-600 mb-2">
              Drag & drop files here, or click to select
            </p>
            <p className="text-xs text-gray-500">
              Max {maxFiles} files, {maxSize}MB each
            </p>
          </>
        )}
      </div>

      {error && (
        <p className="text-sm text-danger">{error}</p>
      )}

      {files.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-700">
            Uploaded Files ({files.length})
          </p>
          {files.map((file, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <FileIcon className="h-5 w-5 text-gray-500" />
                <div>
                  <p className="text-sm font-medium text-gray-900">{file.name}</p>
                  <p className="text-xs text-gray-500">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeFile(index)}
              >
                <XIcon className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
```

**Usage:**
```tsx
<FileUpload
  onUpload={(files) => handleEvidenceUpload(files)}
  maxFiles={5}
  maxSize={50}
  error={uploadError}
/>
```

---

## 4. DATA DISPLAY COMPONENTS

### 4.1 DataTable Component

**Features:** Sorting, Filtering, Pagination, Row Actions

```typescript
// components/data-display/DataTable.tsx

import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
  type ColumnFiltersState,
} from '@tanstack/react-table';
import { useState } from 'react';
import { Input } from '@/components/base/Input';
import { Button } from '@/components/base/Button';
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronsLeftIcon,
  ChevronsRightIcon,
  ArrowUpIcon,
  ArrowDownIcon
} from 'lucide-react';

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  searchPlaceholder?: string;
  onRowClick?: (row: TData) => void;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  searchPlaceholder = "Search...",
  onRowClick
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [globalFilter, setGlobalFilter] = useState('');

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    state: {
      sorting,
      columnFilters,
      globalFilter
    }
  });

  return (
    <div className="space-y-4">
      {/* Search */}
      <Input
        placeholder={searchPlaceholder}
        value={globalFilter}
        onChange={(e) => setGlobalFilter(e.target.value)}
        className="max-w-sm"
      />

      {/* Table */}
      <div className="rounded-md border">
        <table className="w-full">
          <thead className="bg-gray-50">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {header.isPlaceholder ? null : (
                      <div
                        className={
                          header.column.getCanSort()
                            ? 'flex items-center cursor-pointer select-none'
                            : ''
                        }
                        onClick={header.column.getToggleSortingHandler()}
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                        {header.column.getIsSorted() && (
                          <span className="ml-2">
                            {header.column.getIsSorted() === 'desc' ? (
                              <ArrowDownIcon className="h-4 w-4" />
                            ) : (
                              <ArrowUpIcon className="h-4 w-4" />
                            )}
                          </span>
                        )}
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {table.getRowModel().rows.map((row) => (
              <tr
                key={row.id}
                onClick={() => onRowClick?.(row.original)}
                className={onRowClick ? 'cursor-pointer hover:bg-gray-50' : ''}
              >
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id} className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-700">
          Showing {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1} to{' '}
          {Math.min(
            (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
            table.getFilteredRowModel().rows.length
          )}{' '}
          of {table.getFilteredRowModel().rows.length} results
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => table.setPageIndex(0)}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronsLeftIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronLeftIcon className="h-4 w-4" />
          </Button>
          <span className="text-sm text-gray-700">
            Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            <ChevronRightIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
            disabled={!table.getCanNextPage()}
          >
            <ChevronsRightIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
```

**Usage:**
```tsx
const columns: ColumnDef<Case>[] = [
  {
    accessorKey: 'case_number',
    header: 'Case Number',
  },
  {
    accessorKey: 'subject_name',
    header: 'Subject',
  },
  {
    accessorKey: 'severity',
    header: 'Severity',
    cell: ({ row }) => (
      <Badge variant={row.original.severity.toLowerCase()}>
        {row.original.severity}
      </Badge>
    ),
  },
  {
    accessorKey: 'status',
    header: 'Status',
    cell: ({ row }) => (
      <Badge variant={row.original.status.toLowerCase()}>
        {row.original.status}
      </Badge>
    ),
  },
];

<DataTable
  columns={columns}
  data={cases}
  searchPlaceholder="Search cases..."
  onRowClick={(row) => navigate(`/cases/${row.id}`)}
/>
```

### 4.2 Card Component

```typescript
// components/data-display/Card.tsx

import { cn } from '@/lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'bordered' | 'elevated';
}

function Card({ className, variant = 'default', ...props }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-lg bg-white",
        variant === 'bordered' && "border border-gray-200",
        variant === 'elevated' && "shadow-md",
        className
      )}
      {...props}
    />
  );
}

function CardHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("flex flex-col space-y-1.5 p-6", className)}
      {...props}
    />
  );
}

function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3
      className={cn("text-2xl font-semibold leading-none tracking-tight", className)}
      {...props}
    />
  );
}

function CardDescription({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return (
    <p
      className={cn("text-sm text-gray-500", className)}
      {...props}
    />
  );
}

function CardContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-6 pt-0", className)} {...props} />;
}

function CardFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("flex items-center p-6 pt-0", className)}
      {...props}
    />
  );
}

export { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter };
```

**Usage:**
```tsx
<Card variant="elevated">
  <CardHeader>
    <CardTitle>Case Summary</CardTitle>
    <CardDescription>INV-2025-0001</CardDescription>
  </CardHeader>
  <CardContent>
    <p>Investigation details...</p>
  </CardContent>
  <CardFooter>
    <Button>View Details</Button>
  </CardFooter>
</Card>
```

---

## 5. NAVIGATION COMPONENTS

### 5.1 Sidebar Component

```typescript
// components/navigation/Sidebar.tsx

import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  LayoutDashboardIcon,
  FolderOpenIcon,
  FileTextIcon,
  ShieldCheckIcon,
  BarChart3Icon,
  SettingsIcon
} from 'lucide-react';

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

const navigationItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboardIcon },
  { label: 'Cases', href: '/cases', icon: FolderOpenIcon },
  { label: 'Evidence', href: '/evidence', icon: FileTextIcon },
  { label: 'RBI Reports', href: '/rbi-reports', icon: ShieldCheckIcon },
  { label: 'Board View', href: '/board', icon: BarChart3Icon },
  { label: 'Settings', href: '/settings', icon: SettingsIcon },
];

export function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-screen">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-primary-700">Tahakikat</h1>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-1">
        {navigationItems.map((item) => (
          <NavLink
            key={item.href}
            to={item.href}
            className={({ isActive }) =>
              cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary-50 text-primary-700"
                  : "text-gray-700 hover:bg-gray-100"
              )
            }
          >
            <item.icon className="h-5 w-5" />
            <span>{item.label}</span>
            {item.badge && (
              <span className="ml-auto bg-primary-100 text-primary-700 text-xs font-semibold px-2 py-0.5 rounded-full">
                {item.badge}
              </span>
            )}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
```

### 5.2 Breadcrumbs Component

```typescript
// components/navigation/Breadcrumbs.tsx

import { Link } from 'react-router-dom';
import { ChevronRightIcon } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export function Breadcrumbs({ items }: BreadcrumbsProps) {
  return (
    <nav className="flex" aria-label="Breadcrumb">
      <ol className="flex items-center space-x-2">
        {items.map((item, index) => (
          <li key={index} className="flex items-center">
            {index > 0 && (
              <ChevronRightIcon className="h-4 w-4 text-gray-400 mx-2" />
            )}
            {item.href ? (
              <Link
                to={item.href}
                className="text-sm font-medium text-gray-500 hover:text-gray-700"
              >
                {item.label}
              </Link>
            ) : (
              <span className="text-sm font-medium text-gray-900">
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
```

---

## 6. FEEDBACK COMPONENTS

### 6.1 Alert Component

```typescript
// components/feedback/Alert.tsx

import { cva, type VariantProps } from 'class-variance-authority';
import {
  AlertCircleIcon,
  CheckCircle2Icon,
  InfoIcon,
  XCircleIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';

const alertVariants = cva(
  "relative w-full rounded-lg border p-4",
  {
    variants: {
      variant: {
        info: "bg-blue-50 border-blue-200 text-blue-900",
        success: "bg-green-50 border-green-200 text-green-900",
        warning: "bg-yellow-50 border-yellow-200 text-yellow-900",
        danger: "bg-red-50 border-red-200 text-red-900"
      }
    },
    defaultVariants: {
      variant: "info"
    }
  }
);

const iconMap = {
  info: InfoIcon,
  success: CheckCircle2Icon,
  warning: AlertCircleIcon,
  danger: XCircleIcon
};

interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {
  title?: string;
}

export function Alert({ className, variant = 'info', title, children, ...props }: AlertProps) {
  const Icon = iconMap[variant];

  return (
    <div className={cn(alertVariants({ variant }), className)} role="alert" {...props}>
      <div className="flex">
        <Icon className="h-5 w-5 mr-3 flex-shrink-0" />
        <div className="flex-1">
          {title && (
            <h5 className="mb-1 font-medium leading-none tracking-tight">
              {title}
            </h5>
          )}
          <div className="text-sm">{children}</div>
        </div>
      </div>
    </div>
  );
}
```

**Usage:**
```tsx
<Alert variant="warning" title="Missing Evidence">
  Finding F1 has no linked evidence. Please attach supporting documents.
</Alert>

<Alert variant="danger">
  S4 cases require CRO approval before reporting to RBI.
</Alert>
```

### 6.2 Toast Component

```typescript
// components/feedback/Toast.tsx
// Uses react-hot-toast library

import { Toaster } from 'react-hot-toast';

export function ToastProvider() {
  return (
    <Toaster
      position="top-right"
      toastOptions={{
        duration: 4000,
        style: {
          background: '#fff',
          color: '#111827',
          border: '1px solid #e5e7eb',
          borderRadius: '0.5rem',
          padding: '16px'
        },
        success: {
          iconTheme: {
            primary: '#10b981',
            secondary: '#fff'
          }
        },
        error: {
          iconTheme: {
            primary: '#ef4444',
            secondary: '#fff'
          }
        }
      }}
    />
  );
}

// Usage in components:
import toast from 'react-hot-toast';

toast.success('Case created successfully!');
toast.error('Failed to upload evidence');
toast.loading('Generating report...');
```

---

## 7. DOMAIN-SPECIFIC COMPONENTS

### 7.1 CaseCard Component

```typescript
// components/domain/CaseCard.tsx

import { Card, CardHeader, CardContent } from '@/components/data-display/Card';
import { Badge } from '@/components/base/Badge';
import { Button } from '@/components/base/Button';
import { Case } from '@/types';
import { formatDate } from '@/lib/utils';
import { EyeIcon } from 'lucide-react';

interface CaseCardProps {
  case: Case;
  onViewDetails: (caseId: string) => void;
}

export function CaseCard({ case: caseData, onViewDetails }: CaseCardProps) {
  return (
    <Card variant="bordered" className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {caseData.case_number}
            </h3>
            <p className="text-sm text-gray-500 mt-1">
              {caseData.subject_name}
            </p>
          </div>
          <div className="flex space-x-2">
            <Badge variant={caseData.severity.toLowerCase()}>
              {caseData.severity}
            </Badge>
            <Badge variant={caseData.status.toLowerCase()}>
              {caseData.status}
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-3">
          <div>
            <p className="text-sm font-medium text-gray-700">Allegation</p>
            <p className="text-sm text-gray-600 mt-1 line-clamp-2">
              {caseData.allegation_summary}
            </p>
          </div>
          
          {caseData.amount_involved && (
            <div>
              <p className="text-sm font-medium text-gray-700">Amount</p>
              <p className="text-sm text-gray-600 mt-1">
                ₹{caseData.amount_involved.toLocaleString('en-IN')}
              </p>
            </div>
          )}
          
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>Created: {formatDate(caseData.created_at)}</span>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onViewDetails(caseData.id)}
            >
              <EyeIcon className="h-4 w-4 mr-1" />
              View
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
```

### 7.2 EvidenceItem Component

```typescript
// components/domain/EvidenceItem.tsx

import { Badge } from '@/components/base/Badge';
import { Button } from '@/components/base/Button';
import { Evidence } from '@/types';
import { FileIcon, DownloadIcon, LinkIcon, TrashIcon } from 'lucide-react';
import { formatDate, formatFileSize } from '@/lib/utils';

interface EvidenceItemProps {
  evidence: Evidence;
  onDownload: (evidenceId: string) => void;
  onLink: (evidenceId: string) => void;
  onDelete: (evidenceId: string) => void;
}

export function EvidenceItem({
  evidence,
  onDownload,
  onLink,
  onDelete
}: EvidenceItemProps) {
  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow">
      <div className="flex items-start space-x-4">
        {/* File Icon */}
        <div className="flex-shrink-0">
          <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
            <FileIcon className="h-6 w-6 text-blue-600" />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div>
              <h4 className="text-sm font-semibold text-gray-900">
                {evidence.evidence_number}: {evidence.title}
              </h4>
              <p className="text-sm text-gray-600 mt-1">{evidence.file_name}</p>
            </div>
            <Badge variant={evidence.relevance === 'High' ? 'danger' : 'info'}>
              {evidence.relevance}
            </Badge>
          </div>

          <div className="mt-2 flex items-center space-x-4 text-xs text-gray-500">
            <span>{evidence.evidence_type}</span>
            <span>•</span>
            <span>{formatFileSize(evidence.file_size_bytes)}</span>
            <span>•</span>
            <span>{formatDate(evidence.collection_date)}</span>
          </div>

          {evidence.authenticity_verified && (
            <div className="mt-2">
              <Badge variant="success" className="text-xs">
                ✓ Verified
              </Badge>
            </div>
          )}

          {/* Actions */}
          <div className="mt-3 flex items-center space-x-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDownload(evidence.id)}
            >
              <DownloadIcon className="h-4 w-4 mr-1" />
              Download
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onLink(evidence.id)}
            >
              <LinkIcon className="h-4 w-4 mr-1" />
              Link to Finding
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDelete(evidence.id)}
              className="text-danger hover:text-danger"
            >
              <TrashIcon className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
```

### 7.3 ComplianceDecisionPanel Component

```typescript
// components/domain/ComplianceDecisionPanel.tsx

import { Card, CardHeader, CardTitle, CardContent } from '@/components/data-display/Card';
import { Alert } from '@/components/feedback/Alert';
import { FormField } from '@/components/forms/FormField';
import { Button } from '@/components/base/Button';
import { Case, SystemSuggestion } from '@/types';
import { useState } from 'react';

interface ComplianceDecisionPanelProps {
  case: Case;
  systemSuggestion: SystemSuggestion;
  onSubmit: (decision: ComplianceDecision) => void;
}

export function ComplianceDecisionPanel({
  case: caseData,
  systemSuggestion,
  onSubmit
}: ComplianceDecisionPanelProps) {
  const [isReportable, setIsReportable] = useState<boolean | null>(null);
  const [rationale, setRationale] = useState('');
  const [overrideJustification, setOverrideJustification] = useState('');

  const isOverride = isReportable !== null && isReportable !== systemSuggestion.is_reportable;

  const handleSubmit = () => {
    if (isReportable === null) return;
    
    onSubmit({
      is_reportable: isReportable,
      rationale,
      is_override: isOverride,
      override_justification: isOverride ? overrideJustification : undefined
    });
  };

  return (
    <div className="space-y-6">
      {/* System Suggestion */}
      <Card variant="bordered">
        <CardHeader>
          <CardTitle className="text-lg">🤖 System Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-gray-600 mb-2">Based on case details:</p>
            <ul className="text-sm text-gray-700 space-y-1 ml-4 list-disc">
              <li>Severity: {caseData.severity}</li>
              <li>Amount: ₹{caseData.amount_involved?.toLocaleString('en-IN')}</li>
              <li>Evidence: {caseData.evidence_strength}</li>
              <li>Fraud Nature: {caseData.fraud_nature}</li>
            </ul>
          </div>

          <Alert
            variant={systemSuggestion.is_reportable ? 'warning' : 'info'}
            title="SYSTEM SUGGESTION"
          >
            <p className="font-semibold">
              {systemSuggestion.is_reportable ? '✓ REPORTABLE TO RBI' : '✗ NOT REPORTABLE'}
            </p>
            <p className="mt-2 text-sm">{systemSuggestion.rationale}</p>
          </Alert>
        </CardContent>
      </Card>

      {/* Your Decision */}
      <Card variant="bordered">
        <CardHeader>
          <CardTitle className="text-lg">Your Decision</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="decision"
                checked={isReportable === true}
                onChange={() => setIsReportable(true)}
                className="w-4 h-4 text-primary-600"
              />
              <div>
                <p className="font-medium text-gray-900">Reportable to RBI</p>
                <p className="text-sm text-gray-500">
                  {systemSuggestion.is_reportable ? 'Agree with system' : 'Override system'}
                </p>
              </div>
            </label>

            <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="decision"
                checked={isReportable === false}
                onChange={() => setIsReportable(false)}
                className="w-4 h-4 text-primary-600"
              />
              <div>
                <p className="font-medium text-gray-900">Not Reportable</p>
                <p className="text-sm text-gray-500">
                  {!systemSuggestion.is_reportable ? 'Agree with system' : 'Override system'}
                </p>
              </div>
            </label>
          </div>

          <FormField
            id="rationale"
            label="Decision Rationale"
            type="textarea"
            required
            value={rationale}
            onChange={(e) => setRationale(e.target.value)}
            placeholder="Explain your decision..."
            rows={4}
          />

          {isOverride && (
            <>
              <Alert variant="warning" title="Override Detected">
                You are overriding the system suggestion. Please provide detailed justification.
              </Alert>
              
              <FormField
                id="override_justification"
                label="Override Justification"
                type="textarea"
                required
                value={overrideJustification}
                onChange={(e) => setOverrideJustification(e.target.value)}
                placeholder="Why are you overriding the system suggestion?"
                rows={4}
              />

              <Alert variant="info">
                ℹ️ This override will be visible only to:
                <ul className="mt-2 ml-4 list-disc text-sm">
                  <li>Chief Risk Officer (CRO)</li>
                  <li>Internal Audit Team</li>
                </ul>
              </Alert>
            </>
          )}

          <div className="flex justify-end space-x-3">
            <Button variant="secondary">Cancel</Button>
            <Button
              onClick={handleSubmit}
              disabled={isReportable === null || !rationale || (isOverride && !overrideJustification)}
            >
              Submit Decision
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
```

---

## 8. LAYOUT COMPONENTS

### 8.1 DashboardLayout Component

```typescript
// components/layout/DashboardLayout.tsx

import { Sidebar } from '@/components/navigation/Sidebar';
import { TopBar } from '@/components/navigation/TopBar';
import { Outlet } from 'react-router-dom';

export function DashboardLayout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <TopBar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
```

### 8.2 PageHeader Component

```typescript
// components/layout/PageHeader.tsx

import { Breadcrumbs, BreadcrumbItem } from '@/components/navigation/Breadcrumbs';

interface PageHeaderProps {
  title: string;
  description?: string;
  breadcrumbs?: BreadcrumbItem[];
  actions?: React.ReactNode;
}

export function PageHeader({
  title,
  description,
  breadcrumbs,
  actions
}: PageHeaderProps) {
  return (
    <div className="mb-8">
      {breadcrumbs && (
        <div className="mb-4">
          <Breadcrumbs items={breadcrumbs} />
        </div>
      )}
      
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{title}</h1>
          {description && (
            <p className="mt-2 text-gray-600">{description}</p>
          )}
        </div>
        
        {actions && (
          <div className="flex items-center space-x-3">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
```

---

## 9. CODE EXAMPLES

### 9.1 Complete Case List Page

```typescript
// pages/CasesList.tsx

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/base/Button';
import { DataTable } from '@/components/data-display/DataTable';
import { Badge } from '@/components/base/Badge';
import { PlusIcon } from 'lucide-react';
import { Case } from '@/types';
import { getCases } from '@/api/cases';
import { ColumnDef } from '@tanstack/react-table';

export function CasesList() {
  const navigate = useNavigate();
  const { data: cases, isLoading } = useQuery({
    queryKey: ['cases'],
    queryFn: getCases
  });

  const columns: ColumnDef<Case>[] = [
    {
      accessorKey: 'case_number',
      header: 'Case Number',
    },
    {
      accessorKey: 'subject_name',
      header: 'Subject',
    },
    {
      accessorKey: 'case_type',
      header: 'Type',
    },
    {
      accessorKey: 'severity',
      header: 'Severity',
      cell: ({ row }) => (
        <Badge variant={row.original.severity.toLowerCase()}>
          {row.original.severity}
        </Badge>
      ),
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => (
        <Badge variant={row.original.status.toLowerCase()}>
          {row.original.status}
        </Badge>
      ),
    },
    {
      accessorKey: 'amount_involved',
      header: 'Amount',
      cell: ({ row }) => (
        row.original.amount_involved
          ? `₹${row.original.amount_involved.toLocaleString('en-IN')}`
          : '-'
      ),
    },
  ];

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <PageHeader
        title="Investigation Cases"
        description="Manage and track all investigation cases"
        breadcrumbs={[
          { label: 'Dashboard', href: '/dashboard' },
          { label: 'Cases' }
        ]}
        actions={
          <Button onClick={() => navigate('/cases/new')}>
            <PlusIcon className="h-4 w-4 mr-2" />
            New Case
          </Button>
        }
      />

      <DataTable
        columns={columns}
        data={cases || []}
        searchPlaceholder="Search cases..."
        onRowClick={(row) => navigate(`/cases/${row.id}`)}
      />
    </div>
  );
}
```

### 9.2 Create Case Form

```typescript
// pages/CreateCase.tsx

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/data-display/Card';
import { FormField } from '@/components/forms/FormField';
import { Button } from '@/components/base/Button';
import { createCase } from '@/api/cases';
import toast from 'react-hot-toast';

const caseSchema = z.object({
  case_type: z.enum(['Employee_Fraud', 'Vendor_Fraud', 'Employee_Misconduct']),
  severity: z.enum(['S1', 'S2', 'S3', 'S4']),
  subject_name: z.string().min(1, 'Subject name is required'),
  subject_type: z.enum(['Employee', 'Vendor', 'Customer', 'Third_Party']),
  subject_employee_id: z.string().optional(),
  allegation_summary: z.string().min(10, 'Please provide detailed allegation'),
  amount_involved: z.number().optional(),
  detection_date: z.string(),
  fraud_nature: z.string().optional(),
  evidence_strength: z.enum(['Documentary', 'Testimonial', 'Both', 'Weak']),
});

type CaseFormData = z.infer<typeof caseSchema>;

export function CreateCase() {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm<CaseFormData>({
    resolver: zodResolver(caseSchema)
  });

  const createCaseMutation = useMutation({
    mutationFn: createCase,
    onSuccess: (data) => {
      toast.success('Case created successfully!');
      navigate(`/cases/${data.id}`);
    },
    onError: () => {
      toast.error('Failed to create case');
    }
  });

  const onSubmit = (data: CaseFormData) => {
    createCaseMutation.mutate(data);
  };

  return (
    <div>
      <PageHeader
        title="Create New Case"
        breadcrumbs={[
          { label: 'Dashboard', href: '/dashboard' },
          { label: 'Cases', href: '/cases' },
          { label: 'New Case' }
        ]}
      />

      <form onSubmit={handleSubmit(onSubmit)}>
        <Card variant="bordered">
          <CardHeader>
            <CardTitle>Case Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <FormField
                id="case_type"
                label="Case Type"
                type="select"
                required
                {...register('case_type')}
                error={errors.case_type?.message}
                options={[
                  { value: '', label: 'Select case type' },
                  { value: 'Employee_Fraud', label: 'Employee Fraud' },
                  { value: 'Vendor_Fraud', label: 'Vendor Fraud' },
                  { value: 'Employee_Misconduct', label: 'Employee Misconduct' }
                ]}
              />

              <FormField
                id="severity"
                label="Severity"
                type="select"
                required
                {...register('severity')}
                error={errors.severity?.message}
                options={[
                  { value: '', label: 'Select severity' },
                  { value: 'S1', label: 'S1 - Critical' },
                  { value: 'S2', label: 'S2 - High' },
                  { value: 'S3', label: 'S3 - Medium' },
                  { value: 'S4', label: 'S4 - Low' }
                ]}
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <FormField
                id="subject_name"
                label="Subject Name"
                required
                {...register('subject_name')}
                error={errors.subject_name?.message}
                placeholder="Enter subject name"
              />

              <FormField
                id="subject_type"
                label="Subject Type"
                type="select"
                required
                {...register('subject_type')}
                error={errors.subject_type?.message}
                options={[
                  { value: '', label: 'Select subject type' },
                  { value: 'Employee', label: 'Employee' },
                  { value: 'Vendor', label: 'Vendor' },
                  { value: 'Customer', label: 'Customer' },
                  { value: 'Third_Party', label: 'Third Party' }
                ]}
              />
            </div>

            <FormField
              id="allegation_summary"
              label="Allegation Summary"
              type="textarea"
              required
              {...register('allegation_summary')}
              error={errors.allegation_summary?.message}
              placeholder="Provide detailed summary of the allegation"
              rows={4}
            />

            <div className="grid grid-cols-2 gap-6">
              <FormField
                id="amount_involved"
                label="Amount Involved"
                type="number"
                {...register('amount_involved', { valueAsNumber: true })}
                error={errors.amount_involved?.message}
                placeholder="Enter amount in INR"
              />

              <FormField
                id="detection_date"
                label="Detection Date"
                type="date"
                required
                {...register('detection_date')}
                error={errors.detection_date?.message}
              />
            </div>

            <FormField
              id="evidence_strength"
              label="Evidence Strength"
              type="select"
              required
              {...register('evidence_strength')}
              error={errors.evidence_strength?.message}
              options={[
                { value: '', label: 'Select evidence strength' },
                { value: 'Documentary', label: 'Documentary' },
                { value: 'Testimonial', label: 'Testimonial' },
                { value: 'Both', label: 'Both (Documentary & Testimonial)' },
                { value: 'Weak', label: 'Weak / Insufficient' }
              ]}
            />

            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => navigate('/cases')}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                isLoading={createCaseMutation.isPending}
              >
                Create Case
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
```

---

## 10. STORYBOOK DOCUMENTATION

Each component should have a Storybook story for documentation and testing.

Example:

```typescript
// components/base/Button.stories.tsx

import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './Button';

const meta = {
  title: 'Base/Button',
  component: Button,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    children: 'Primary Button',
    variant: 'primary',
  },
};

export const Secondary: Story = {
  args: {
    children: 'Secondary Button',
    variant: 'secondary',
  },
};

export const Loading: Story = {
  args: {
    children: 'Loading...',
    isLoading: true,
  },
};

export const Disabled: Story = {
  args: {
    children: 'Disabled Button',
    disabled: true,
  },
};
```

---

## SUMMARY

This UI component library provides:

1. **Reusable Components** - Built once, used everywhere
2. **Type Safety** - Full TypeScript support
3. **Accessibility** - WCAG compliant
4. **Consistency** - Unified design language
5. **Maintainability** - Easy to update and extend

**Next Steps:**
1. Set up the component library structure
2. Implement base components
3. Build form and data display components
4. Create domain-specific components
5. Document in Storybook
6. Write unit tests for each component

This will give you a solid foundation for building the Tahakikat platform UI! 🚀
