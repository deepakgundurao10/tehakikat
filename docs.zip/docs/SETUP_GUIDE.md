# 🚀 Deepak's Independence Cookbook
## Getting Your Development Environment Ready

Welcome Deepak! This guide will walk you through everything you need to run the Investigation Report Platform on your own laptop. By the end, you'll be able to:
- Run the app locally
- Make changes to the interface
- Test new features
- Work with Claude to refine the product

**Time needed:** About 1-2 hours for initial setup

---

## 📋 Prerequisites Checklist

Before we start, let's make sure you have everything. Check each box as you complete it:

```
□ Windows/Mac laptop with at least 8GB RAM
□ Internet connection
□ Admin access to install software
□ Your Neon database connection (you already have this ✓)
□ Anthropic API key (we'll get this)
□ GitHub account (we'll set this up if needed)
```

---

## PART 1: Installing the Essential Tools

### Step 1.1: Install VS Code (Your Code Editor)

VS Code is where you'll view and edit code. Think of it like Microsoft Word, but for programming.

**Download:** https://code.visualstudio.com/download

1. Go to the website
2. Click the big download button for your operating system (Windows/Mac)
3. Run the installer
4. Accept all defaults, click "Next" through everything
5. ✅ Check "Add to PATH" if asked
6. Finish installation

**Verify it works:**
- Open VS Code from your Start Menu or Applications
- You should see a welcome screen

---

### Step 1.2: Install Python (Backend Language)

Python runs the backend server that talks to your database.

**Download:** https://www.python.org/downloads/

1. Click "Download Python 3.12.x" (or latest version)
2. Run the installer
3. ⚠️ **CRITICAL:** Check the box that says **"Add Python to PATH"** at the bottom of the first screen
4. Click "Install Now"
5. Wait for installation to complete

**Verify it works:**
Open a terminal (see "How to Open Terminal" below) and type:
```bash
python --version
```
You should see something like `Python 3.12.1`

---

### Step 1.3: Install Node.js (Frontend Language)

Node.js runs the React frontend - the user interface you see.

**Download:** https://nodejs.org/

1. Click the **LTS** version (Long Term Support - the safer choice)
2. Run the installer
3. Accept all defaults
4. Finish installation

**Verify it works:**
In your terminal, type:
```bash
node --version
npm --version
```
You should see version numbers for both.

---

### Step 1.4: Install Git (Version Control)

Git lets you download code from GitHub and save your changes.

**Download:** https://git-scm.com/downloads

1. Download for your operating system
2. Run installer
3. Accept all defaults (there are many screens - just keep clicking Next)
4. Finish installation

**Verify it works:**
```bash
git --version
```
Should show something like `git version 2.43.0`

---

## 📂 How to Open Terminal

You'll use the terminal to run commands. Here's how to open it:

**Windows:**
- Press `Windows key + R`
- Type `cmd` and press Enter
- OR: Search for "Command Prompt" in Start Menu
- OR: In VS Code, press `` Ctrl + ` `` (backtick key, usually below Escape)

**Mac:**
- Press `Cmd + Space`
- Type "Terminal" and press Enter
- OR: In VS Code, press `` Cmd + ` ``

**Pro Tip:** Always use the terminal inside VS Code - it's more convenient!

---

## PART 2: Getting Your API Key

### Step 2.1: Create Anthropic Account & Get API Key

The API key lets your app talk to Claude to generate reports.

1. Go to: https://console.anthropic.com/
2. Sign up for an account (or sign in if you have one)
3. After signing in, click on **"API Keys"** in the left sidebar
4. Click **"Create Key"**
5. Give it a name like "Investigation Platform"
6. **COPY THE KEY IMMEDIATELY** - you can only see it once!
7. Save it somewhere safe (like a password manager or secure note)

Your key will look like: `sk-ant-api03-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

⚠️ **Important:** Never share this key publicly or commit it to GitHub!

---

### Step 2.2: Add Credits to Your Anthropic Account

The API has usage costs (very small - maybe $1-5 for testing):

1. In the Anthropic Console, go to **"Billing"**
2. Add a payment method
3. Add some credits ($10-20 is plenty for testing)

---

## PART 3: Getting the Code

### Step 3.1: Clone the Repository

Rajeev has pushed all the code to GitHub. Now you'll download it.

1. Open VS Code
2. Press `Ctrl + `` ` (or `Cmd + `` ` on Mac) to open terminal
3. Navigate to where you want the project:
   ```bash
   cd Desktop
   ```
4. Clone the repository (Rajeev will give you the exact URL):
   ```bash
   git clone https://github.com/RAJEEV_USERNAME/investigation-platform.git
   ```
5. Open the project folder:
   ```bash
   cd investigation-platform
   ```
6. Open it in VS Code:
   ```bash
   code .
   ```

Now you should see all the project files in VS Code's left sidebar!

---

## PART 4: Setting Up the Backend

### Step 4.1: Create Virtual Environment

A virtual environment keeps this project's Python packages separate from other projects.

In the terminal (inside VS Code), run:

```bash
# Navigate to backend folder
cd backend

# Create virtual environment
python -m venv venv

# Activate it (Windows)
venv\Scripts\activate

# OR Activate it (Mac/Linux)
source venv/bin/activate
```

You'll know it worked when you see `(venv)` at the start of your terminal line.

---

### Step 4.2: Install Python Packages

With the virtual environment activated:

```bash
pip install -r requirements.txt
```

This installs all the libraries the backend needs. Wait for it to finish.

---

### Step 4.3: Create Your Environment File

Create a file called `.env` in the `backend` folder:

1. In VS Code, right-click on the `backend` folder
2. Click "New File"
3. Name it `.env` (yes, starting with a dot)
4. Paste this content:

```env
# Neon Database Connection (your connection string)
DATABASE_URL=postgresql://neondb_owner:npg_0wQZmnBGXo7Y@ep-broad-paper-ahvprb0z-pooler.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require

# Your Anthropic API Key (replace with your actual key)
ANTHROPIC_API_KEY=sk-ant-api03-YOUR-ACTUAL-KEY-HERE

# Server Config
HOST=0.0.0.0
PORT=8000
DEBUG=True
```

**Replace `sk-ant-api03-YOUR-ACTUAL-KEY-HERE` with your real API key!**

---

### Step 4.4: Start the Backend Server

```bash
uvicorn app.main:app --reload
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
```

✅ **Test it:** Open your browser and go to http://localhost:8000
You should see: `{"name": "Investigation Report Automation Platform", ...}`

**Leave this terminal running!** Open a new terminal for the frontend.

---

## PART 5: Setting Up the Frontend

### Step 5.1: Open New Terminal

In VS Code:
- Click the `+` icon in the terminal panel to open a new terminal
- Or press `Ctrl + Shift + `` ` (Windows) or `Cmd + Shift + `` ` (Mac)

### Step 5.2: Navigate to Frontend & Install

```bash
# Go to frontend folder
cd frontend

# Install all packages (this takes a minute)
npm install
```

---

### Step 5.3: Start the Frontend Server

```bash
npm run dev
```

You should see:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

✅ **Test it:** Open your browser and go to http://localhost:5173

🎉 **You should see the Investigation Platform interface!**

---

## PART 6: Your Daily Workflow

Every time you want to work on the project:

### Starting Up (Do This Each Session)

```bash
# Terminal 1: Backend
cd investigation-platform/backend
venv\Scripts\activate  # or: source venv/bin/activate on Mac
uvicorn app.main:app --reload

# Terminal 2: Frontend (new terminal)
cd investigation-platform/frontend
npm run dev
```

### Shutting Down

- Press `Ctrl + C` in each terminal to stop the servers
- Close VS Code

---

## PART 7: Making Changes (The Fun Part!)

### Where Things Live

```
investigation-platform/
├── backend/                    # Python server code
│   ├── app/
│   │   ├── main.py            # Main server file
│   │   ├── models.py          # Database structure
│   │   ├── routers/           # API endpoints
│   │   └── services/          # Business logic (AI generation)
│   └── .env                   # Your secrets (don't share!)
│
├── frontend/                   # React interface code
│   ├── src/
│   │   ├── App.jsx            # Main app component
│   │   ├── pages/             # Different screens
│   │   ├── components/        # Reusable UI pieces
│   │   └── api/               # Talks to backend
│   └── package.json           # Frontend dependencies
```

### Common Changes You Might Make

**Change button text or labels:**
→ Look in `frontend/src/components/` or `frontend/src/pages/`

**Change form fields or dropdowns:**
→ Look in the component files for the page you want to modify

**Change how the report is generated:**
→ Look in `backend/app/services/report_generator.py`

**Change database fields:**
→ Look in `backend/app/models.py` (but be careful - this affects data storage)

---

## PART 8: Working with Claude (Your AI Partner)

You have Claude Max subscription - use it! Here's how to get help:

### Asking Claude to Modify Code

Copy the file content and ask Claude:
> "Here's my React component for the Dashboard. I want to add a search bar that filters cases by subject. Can you modify this code?"

### Asking Claude to Explain Code

> "Can you explain what this Python function does? [paste function]"

### Asking Claude to Debug

> "I'm getting this error when I click the Generate Report button: [paste error]. Here's my code: [paste code]. What's wrong?"

### Asking Claude to Add Features

> "I want to add a feature where users can mark evidence as 'primary' or 'secondary'. What files do I need to modify and what changes should I make?"

---

## PART 9: Saving Your Changes (Git Basics)

After making changes, save them to GitHub:

### Check What Changed
```bash
git status
```

### Save Your Changes
```bash
# Stage all changes
git add .

# Commit with a message describing what you did
git commit -m "Added search filter to dashboard"

# Push to GitHub
git push
```

### Get Latest Changes (If Rajeev Made Updates)
```bash
git pull
```

---

## 🔧 Troubleshooting Common Issues

### "python is not recognized"
→ Python wasn't added to PATH. Reinstall Python and check "Add to PATH"

### "npm is not recognized"
→ Node.js wasn't installed properly. Reinstall Node.js

### "Module not found" error in backend
→ Make sure virtual environment is activated (you see `(venv)` in terminal)
→ Run `pip install -r requirements.txt` again

### "Cannot connect to database"
→ Check your DATABASE_URL in `.env` file
→ Make sure there are no extra spaces or line breaks

### "API key invalid"
→ Check your ANTHROPIC_API_KEY in `.env` file
→ Make sure you copied the whole key

### Frontend shows blank page
→ Check the browser console (F12 → Console tab) for errors
→ Make sure backend is running

### "Port already in use"
→ Another server is running. Find and close it, or use a different port:
```bash
# Backend on different port
uvicorn app.main:app --reload --port 8001

# Frontend on different port
npm run dev -- --port 5174
```

---

## 📞 Getting Help

### If You're Stuck:

1. **First:** Copy the exact error message
2. **Then:** Ask Claude Max to help diagnose
3. **Still stuck?:** Message Rajeev with:
   - What you were trying to do
   - The exact error message
   - What you already tried

### Useful Resources:

- **VS Code Tips:** https://code.visualstudio.com/docs/getstarted/tips-and-tricks
- **Python Basics:** https://www.python.org/about/gettingstarted/
- **React Basics:** https://react.dev/learn
- **Git Basics:** https://git-scm.com/book/en/v2/Getting-Started-Git-Basics

---

## ✅ Success Checklist

Before your first independent session, verify:

```
□ VS Code opens and shows the project files
□ Backend starts without errors (http://localhost:8000 works)
□ Frontend starts without errors (http://localhost:5173 works)
□ You can create a new case in the UI
□ You can add evidence to a case
□ Report generation works (uses your API key)
□ You know how to stop and restart the servers
□ You know how to ask Claude for help
```

---

## 🎯 Your First Solo Exercise

Once everything is running, try this:

1. Open the Dashboard page in your browser
2. Find the corresponding file in VS Code (`frontend/src/pages/Dashboard.jsx`)
3. Find the text "Investigation Cases" in the code
4. Change it to "Investigation Dashboard" 
5. Save the file (Ctrl + S)
6. Watch the browser automatically refresh with your change!

If that worked, you're ready to start making real modifications.

---

## 🗓️ Next Steps with Rajeev

After you're comfortable with the setup:

1. **Week 1:** Play with the UI, make small text/color changes
2. **Week 2:** Add a new field to the case form
3. **Week 3:** Deploy to a real website for beta testers
4. **Week 4:** Gather feedback and iterate

---

**You've got this, Deepak! 🚀**

The hardest part (the PRD) is already done. Now it's just refining until it's exactly what you envisioned.

Remember: Every developer started exactly where you are now. The difference is just practice.