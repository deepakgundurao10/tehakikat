# Tahakikat - Technical Architecture & UI/UX Specifications
## Investigation, Fraud Governance & RBI Regulatory Reporting Platform

---

## 1. SYSTEM ARCHITECTURE OVERVIEW

### 1.1 Architecture Pattern
**Clean Architecture with Domain-Driven Design (DDD)**

```
┌─────────────────────────────────────────────────────┐
│                  Presentation Layer                  │
│  (React Frontend + Progressive Web App)             │
└────────────────┬────────────────────────────────────┘
                 │
┌────────────────┴────────────────────────────────────┐
│               API Gateway Layer                      │
│  (FastAPI / NestJS with JWT + Role-Based Access)   │
└────────────────┬────────────────────────────────────┘
                 │
┌────────────────┴────────────────────────────────────┐
│              Application Layer                       │
│  (Use Cases / Business Logic / Orchestration)       │
└────────────────┬────────────────────────────────────┘
                 │
┌────────────────┴────────────────────────────────────┐
│               Domain Layer                           │
│  (Entities / Value Objects / Domain Services)       │
└────────────────┬────────────────────────────────────┘
                 │
┌────────────────┴────────────────────────────────────┐
│            Infrastructure Layer                      │
│  (PostgreSQL / Neon / File Storage / AI Services)  │
└─────────────────────────────────────────────────────┘
```

### 1.2 Technology Stack

#### Frontend Stack
- **Framework**: React 18+ with TypeScript
- **State Management**: Zustand (simpler than Redux, perfect for your use case)
- **UI Library**: Shadcn/ui + Tailwind CSS (modern, customizable, accessible)
- **Forms**: React Hook Form + Zod validation
- **Data Fetching**: TanStack Query (React Query)
- **Routing**: React Router v6
- **Charts**: Recharts or Chart.js
- **Tables**: TanStack Table (formerly React Table)
- **Date Handling**: date-fns
- **File Upload**: react-dropzone
- **Rich Text**: Tiptap or Lexical (for case notes)
- **PDF Generation**: react-pdf/renderer
- **Build Tool**: Vite

#### Backend Stack
- **Language**: Python 3.11+
- **Framework**: FastAPI (async, modern, auto-docs)
- **ORM**: SQLAlchemy 2.0 with Alembic migrations
- **Database**: PostgreSQL (Neon hosted)
- **Authentication**: JWT tokens with refresh strategy
- **File Storage**: AWS S3 or Neon Object Storage
- **AI Integration**: Anthropic Claude API (Sonnet 4.5)
- **Document Generation**: python-docx for Word, reportlab for PDF
- **Background Tasks**: Celery + Redis (for report generation queue)
- **API Documentation**: OpenAPI (Swagger) auto-generated

#### Infrastructure & DevOps
- **Version Control**: Git + GitHub
- **CI/CD**: GitHub Actions
- **Hosting**: Vercel (frontend) + Railway/Render (backend)
- **Database**: Neon (serverless PostgreSQL)
- **Monitoring**: Sentry (error tracking)
- **Analytics**: PostHog (privacy-focused)

---

## 2. DATABASE SCHEMA DESIGN

### 2.1 Core Entity Relationship

```
Users (1) ───── (M) Cases
Cases (1) ───── (M) Findings
Cases (1) ───── (M) Evidence
Cases (1) ───── (M) Interviews
Cases (1) ───── (M) Reviews
Cases (1) ───── (M) ComplianceDecisions
Cases (1) ───── (M) RBIReports
Cases (1) ───── (M) AuditLogs
Evidence (M) ─── (M) Findings (many-to-many)
```

### 2.2 Database Tables

#### users
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL, -- Investigator, RCU_Reviewer, Compliance_Officer, CRO, Internal_Audit, Board
    department VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

#### cases
```sql
CREATE TABLE cases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_number VARCHAR(50) UNIQUE NOT NULL, -- Auto-generated: INV-2025-0001
    case_type VARCHAR(50) NOT NULL, -- Employee_Fraud, Vendor_Fraud, Employee_Misconduct
    status VARCHAR(50) NOT NULL, -- Draft, Investigation, RCU_Review, Compliance_Decision, Closed
    severity VARCHAR(10) NOT NULL, -- S1, S2, S3, S4
    
    -- Subject Details
    subject_name VARCHAR(255) NOT NULL,
    subject_type VARCHAR(50) NOT NULL, -- Employee, Vendor, Customer, Third_Party
    subject_employee_id VARCHAR(100),
    subject_department VARCHAR(100),
    subject_designation VARCHAR(100),
    
    -- Case Details
    allegation_summary TEXT NOT NULL,
    amount_involved DECIMAL(15, 2),
    currency VARCHAR(10) DEFAULT 'INR',
    incident_date DATE,
    detection_date DATE NOT NULL,
    reporting_date DATE,
    
    -- Classification
    fraud_nature VARCHAR(100), -- Per RBI taxonomy
    perpetrator_type VARCHAR(50),
    modus_operandi TEXT,
    evidence_strength VARCHAR(50), -- Documentary, Testimonial, Both, Weak
    impact_type VARCHAR(100), -- Financial, Reputational, Legal, Operational
    
    -- Metadata
    created_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    closed_at TIMESTAMP,
    closed_by UUID REFERENCES users(id),
    closure_reason TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_severity CHECK (severity IN ('S1', 'S2', 'S3', 'S4')),
    CONSTRAINT chk_status CHECK (status IN ('Draft', 'Investigation', 'RCU_Review', 'Compliance_Decision', 'Closed'))
);

CREATE INDEX idx_cases_case_number ON cases(case_number);
CREATE INDEX idx_cases_status ON cases(status);
CREATE INDEX idx_cases_severity ON cases(severity);
CREATE INDEX idx_cases_created_by ON cases(created_by);
CREATE INDEX idx_cases_detection_date ON cases(detection_date);
```

#### evidence
```sql
CREATE TABLE evidence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    evidence_number VARCHAR(50) NOT NULL, -- E1, E2, E3...
    
    -- Evidence Details
    evidence_type VARCHAR(100) NOT NULL, -- Email, Bank_Statement, Invoice, CCTV, Screenshot, etc.
    title VARCHAR(255) NOT NULL,
    description TEXT,
    source VARCHAR(255), -- Where obtained from
    collection_date DATE NOT NULL,
    collection_method VARCHAR(100), -- Email_Export, System_Extract, Physical_Copy
    
    -- File Details
    file_path VARCHAR(500),
    file_name VARCHAR(255),
    file_size_bytes BIGINT,
    file_hash VARCHAR(64), -- SHA-256 for integrity
    
    -- Classification
    relevance VARCHAR(50), -- High, Medium, Low
    authenticity_verified BOOLEAN DEFAULT false,
    chain_of_custody_notes TEXT,
    
    -- Metadata
    uploaded_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(case_id, evidence_number)
);

CREATE INDEX idx_evidence_case_id ON evidence(case_id);
CREATE INDEX idx_evidence_type ON evidence(evidence_type);
```

#### findings
```sql
CREATE TABLE findings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    finding_number VARCHAR(50) NOT NULL, -- F1, F2, F3...
    
    category VARCHAR(100) NOT NULL, -- Policy_Violation, Fraud, Misconduct, Process_Gap
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    facts_established TEXT NOT NULL,
    inference TEXT,
    risk_rating VARCHAR(50), -- Critical, High, Medium, Low
    
    -- Red Flags
    is_red_flag BOOLEAN DEFAULT false,
    red_flag_details TEXT,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(case_id, finding_number)
);

CREATE INDEX idx_findings_case_id ON findings(case_id);
CREATE INDEX idx_findings_is_red_flag ON findings(is_red_flag);
```

#### evidence_finding_links
```sql
CREATE TABLE evidence_finding_links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    evidence_id UUID REFERENCES evidence(id) ON DELETE CASCADE,
    finding_id UUID REFERENCES findings(id) ON DELETE CASCADE,
    relevance_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(evidence_id, finding_id)
);

CREATE INDEX idx_evidence_finding_evidence ON evidence_finding_links(evidence_id);
CREATE INDEX idx_evidence_finding_finding ON evidence_finding_links(finding_id);
```

#### interviews
```sql
CREATE TABLE interviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    interview_number VARCHAR(50) NOT NULL, -- I1, I2, I3...
    
    -- Interviewee Details
    interviewee_name VARCHAR(255) NOT NULL,
    interviewee_role VARCHAR(100),
    interviewee_department VARCHAR(100),
    relationship_to_case VARCHAR(100), -- Subject, Witness, Approver, Colleague
    
    -- Interview Details
    interview_date DATE NOT NULL,
    interview_mode VARCHAR(50), -- In_Person, Video, Phone, Written
    conducted_by UUID REFERENCES users(id),
    location VARCHAR(255),
    duration_minutes INT,
    
    -- Content
    statement_summary TEXT NOT NULL,
    key_admissions TEXT,
    management_explanation TEXT,
    is_contradictory BOOLEAN DEFAULT false,
    contradicts_note TEXT,
    
    -- Recording
    recording_available BOOLEAN DEFAULT false,
    recording_file_path VARCHAR(500),
    transcript_file_path VARCHAR(500),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(case_id, interview_number)
);

CREATE INDEX idx_interviews_case_id ON interviews(case_id);
CREATE INDEX idx_interviews_date ON interviews(interview_date);
```

#### rcu_reviews
```sql
CREATE TABLE rcu_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    
    reviewer_id UUID REFERENCES users(id) NOT NULL,
    review_date DATE NOT NULL,
    
    -- Review Assessment
    findings_validated BOOLEAN,
    evidence_adequate BOOLEAN,
    investigation_complete BOOLEAN,
    
    recommendation VARCHAR(100) NOT NULL, -- Report_to_RBI, No_Report, Further_Investigation
    recommendation_rationale TEXT NOT NULL,
    
    additional_comments TEXT,
    escalated_to_cro BOOLEAN DEFAULT false,
    escalation_reason TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_rcu_reviews_case_id ON rcu_reviews(case_id);
CREATE INDEX idx_rcu_reviews_reviewer ON rcu_reviews(reviewer_id);
```

#### compliance_decisions
```sql
CREATE TABLE compliance_decisions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    
    -- Decision Authority
    decided_by UUID REFERENCES users(id) NOT NULL,
    decision_date DATE NOT NULL,
    
    -- System Suggestion
    system_suggested_reportable BOOLEAN,
    system_suggestion_rationale TEXT,
    
    -- Actual Decision
    is_reportable_to_rbi BOOLEAN NOT NULL,
    decision_rationale TEXT NOT NULL,
    
    -- Override Tracking
    is_override BOOLEAN DEFAULT false, -- Did compliance override system suggestion?
    override_justification TEXT,
    override_visible_to VARCHAR(50), -- CRO_Only, Audit_Team, Management
    
    -- S4 Special Handling
    requires_cro_approval BOOLEAN DEFAULT false,
    cro_approved BOOLEAN,
    cro_approval_date DATE,
    cro_approval_notes TEXT,
    ceo_notified BOOLEAN DEFAULT false,
    ceo_notification_date DATE,
    
    -- Classification
    fraud_classification VARCHAR(100), -- Per RBI taxonomy
    amount_bucket VARCHAR(50), -- <1L, 1-5L, 5-10L, >10L
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_compliance_decisions_case_id ON compliance_decisions(case_id);
CREATE INDEX idx_compliance_decisions_decided_by ON compliance_decisions(decided_by);
CREATE INDEX idx_compliance_decisions_is_override ON compliance_decisions(is_override);
```

#### rbi_reports
```sql
CREATE TABLE rbi_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    
    report_type VARCHAR(10) NOT NULL, -- FMR-1, FMR-2, FMR-3
    report_date DATE NOT NULL,
    
    -- Timeline Tracking
    due_date DATE NOT NULL,
    submitted_date DATE,
    is_delayed BOOLEAN DEFAULT false,
    delay_reason TEXT,
    
    -- Report Content (JSON for flexibility)
    report_data JSONB NOT NULL,
    
    -- Reclassification Tracking
    original_classification VARCHAR(100),
    reclassified_to VARCHAR(100),
    reclassification_date DATE,
    reclassification_reason TEXT,
    
    -- Submission
    submitted_by UUID REFERENCES users(id),
    submission_reference VARCHAR(100),
    
    -- Document
    report_file_path VARCHAR(500),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_rbi_reports_case_id ON rbi_reports(case_id);
CREATE INDEX idx_rbi_reports_type ON rbi_reports(report_type);
CREATE INDEX idx_rbi_reports_due_date ON rbi_reports(due_date);
```

#### audit_logs
```sql
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Event Details
    entity_type VARCHAR(50) NOT NULL, -- Case, Evidence, Finding, Review, Decision
    entity_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL, -- Created, Updated, Deleted, Viewed, Exported
    
    -- User Context
    user_id UUID REFERENCES users(id),
    user_role VARCHAR(50),
    user_ip VARCHAR(45),
    
    -- Change Tracking
    changes JSONB, -- Before/After values
    reason TEXT,
    
    -- Metadata
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Search Optimization
    search_vector TSVECTOR
);

CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_logs_search ON audit_logs USING GIN(search_vector);
```

#### report_templates
```sql
CREATE TABLE report_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    template_name VARCHAR(255) NOT NULL,
    template_type VARCHAR(50) NOT NULL, -- Investigation, Board, Management, RBI
    
    -- Template Content
    structure JSONB NOT NULL, -- Section definitions
    tone_rules JSONB, -- Tone logic based on conditions
    language_safeguards JSONB, -- Prohibited phrases, required cautionary text
    
    is_active BOOLEAN DEFAULT true,
    version INT DEFAULT 1,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_templates_type ON report_templates(template_type);
CREATE INDEX idx_templates_active ON report_templates(is_active);
```

---

## 3. API ARCHITECTURE

### 3.1 API Structure

```
/api/v1/
├── /auth/
│   ├── POST   /login
│   ├── POST   /logout
│   ├── POST   /refresh-token
│   └── GET    /me
│
├── /cases/
│   ├── GET    /                    # List cases with filters
│   ├── POST   /                    # Create new case
│   ├── GET    /{caseId}           # Get case details
│   ├── PUT    /{caseId}           # Update case
│   ├── DELETE /{caseId}           # Delete case (soft delete)
│   ├── POST   /{caseId}/close     # Close case
│   └── GET    /{caseId}/timeline  # Case activity timeline
│
├── /evidence/
│   ├── GET    /case/{caseId}      # List evidence for case
│   ├── POST   /case/{caseId}      # Upload evidence
│   ├── GET    /{evidenceId}       # Get evidence details
│   ├── PUT    /{evidenceId}       # Update evidence metadata
│   ├── DELETE /{evidenceId}       # Delete evidence
│   └── GET    /{evidenceId}/download
│
├── /findings/
│   ├── GET    /case/{caseId}      # List findings
│   ├── POST   /case/{caseId}      # Create finding
│   ├── PUT    /{findingId}        # Update finding
│   ├── DELETE /{findingId}        # Delete finding
│   └── POST   /{findingId}/link-evidence
│
├── /interviews/
│   ├── GET    /case/{caseId}
│   ├── POST   /case/{caseId}
│   ├── PUT    /{interviewId}
│   └── DELETE /{interviewId}
│
├── /reviews/
│   ├── GET    /case/{caseId}
│   ├── POST   /case/{caseId}      # Submit RCU review
│   └── GET    /{reviewId}
│
├── /decisions/
│   ├── GET    /case/{caseId}
│   ├── POST   /case/{caseId}      # Submit compliance decision
│   ├── PUT    /{decisionId}       # Update decision (logged)
│   └── POST   /{decisionId}/cro-approval
│
├── /rbi-reports/
│   ├── GET    /case/{caseId}
│   ├── POST   /case/{caseId}      # Generate RBI report
│   ├── GET    /{reportId}
│   ├── PUT    /{reportId}         # Update report
│   ├── POST   /{reportId}/reclassify
│   └── POST   /{reportId}/submit
│
├── /reports/
│   ├── POST   /generate           # Generate investigation report
│   ├── GET    /{reportId}/status  # Check generation status
│   ├── GET    /{reportId}/download
│   └── POST   /{reportId}/regenerate
│
├── /dashboard/
│   ├── GET    /overview           # Stats and KPIs
│   ├── GET    /cases-by-status
│   ├── GET    /cases-by-severity
│   ├── GET    /timeline-trends
│   └── GET    /compliance-metrics
│
├── /audit/
│   ├── GET    /logs               # Audit trail with filters
│   ├── GET    /entity/{entityType}/{entityId}
│   └── GET    /user/{userId}
│
├── /users/
│   ├── GET    /                   # List users (admin only)
│   ├── POST   /                   # Create user (admin only)
│   ├── GET    /{userId}
│   ├── PUT    /{userId}
│   └── DELETE /{userId}
│
└── /ai/
    ├── POST   /generate-report-draft
    ├── POST   /suggest-findings
    ├── POST   /classify-fraud
    ├── POST   /generate-board-narrative
    └── POST   /summarize-evidence
```

### 3.2 Request/Response Examples

#### Create Case
```json
POST /api/v1/cases/
{
  "case_type": "Employee_Fraud",
  "severity": "S3",
  "subject_name": "John Doe",
  "subject_type": "Employee",
  "subject_employee_id": "EMP12345",
  "allegation_summary": "Suspected invoice manipulation in vendor payments",
  "amount_involved": 250000.00,
  "detection_date": "2025-02-01",
  "fraud_nature": "Misappropriation_Of_Funds",
  "evidence_strength": "Documentary"
}

Response: 201 Created
{
  "id": "uuid-here",
  "case_number": "INV-2025-0001",
  "status": "Draft",
  ...created case object
}
```

#### Generate Report
```json
POST /api/v1/reports/generate
{
  "case_id": "uuid-here",
  "report_type": "Investigation",
  "tone": "Strict",
  "include_annexures": true,
  "output_format": "docx"
}

Response: 202 Accepted
{
  "report_id": "report-uuid",
  "status": "generating",
  "estimated_completion": "2025-02-10T10:35:00Z"
}
```

---

## 4. UI/UX DESIGN SPECIFICATIONS

### 4.1 Design System

#### Color Palette
```css
/* Primary Colors */
--primary-900: #1e3a8a;    /* Deep blue - headers, main actions */
--primary-700: #1d4ed8;    /* Blue - primary buttons */
--primary-500: #3b82f6;    /* Light blue - links, accents */
--primary-100: #dbeafe;    /* Very light blue - backgrounds */

/* Status Colors */
--success: #10b981;        /* Green - completed, verified */
--warning: #f59e0b;        /* Orange - pending, needs attention */
--danger: #ef4444;         /* Red - critical, errors */
--info: #3b82f6;           /* Blue - informational */

/* Severity Colors */
--severity-s1: #ef4444;    /* S1 - Critical (Red) */
--severity-s2: #f59e0b;    /* S2 - High (Orange) */
--severity-s3: #3b82f6;    /* S3 - Medium (Blue) */
--severity-s4: #6b7280;    /* S4 - Low (Gray) */

/* Neutral Colors */
--gray-50: #f9fafb;
--gray-100: #f3f4f6;
--gray-200: #e5e7eb;
--gray-500: #6b7280;
--gray-700: #374151;
--gray-900: #111827;

/* Semantic Colors */
--background: #ffffff;
--surface: #f9fafb;
--border: #e5e7eb;
--text-primary: #111827;
--text-secondary: #6b7280;
--text-disabled: #9ca3af;
```

#### Typography
```css
/* Font Family */
--font-sans: 'Inter', system-ui, -apple-system, sans-serif;
--font-mono: 'JetBrains Mono', monospace;

/* Font Sizes */
--text-xs: 0.75rem;    /* 12px */
--text-sm: 0.875rem;   /* 14px */
--text-base: 1rem;     /* 16px */
--text-lg: 1.125rem;   /* 18px */
--text-xl: 1.25rem;    /* 20px */
--text-2xl: 1.5rem;    /* 24px */
--text-3xl: 1.875rem;  /* 30px */

/* Font Weights */
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;
```

#### Spacing System
```css
--spacing-1: 0.25rem;   /* 4px */
--spacing-2: 0.5rem;    /* 8px */
--spacing-3: 0.75rem;   /* 12px */
--spacing-4: 1rem;      /* 16px */
--spacing-6: 1.5rem;    /* 24px */
--spacing-8: 2rem;      /* 32px */
--spacing-12: 3rem;     /* 48px */
```

### 4.2 Core UI Components

#### Navigation Structure
```
┌─────────────────────────────────────────────────────┐
│ TAHAKIKAT                    [Profile] [Logout]     │
├─────────────────────────────────────────────────────┤
│                                                      │
│ ┌─ Sidebar ─┐  ┌──── Main Content ─────────────┐  │
│ │            │  │                                │  │
│ │ Dashboard  │  │  [Page Header]                 │  │
│ │ Cases      │  │                                │  │
│ │ Evidence   │  │  [Content Area]                │  │
│ │ RBI Reports│  │                                │  │
│ │ Board View │  │                                │  │
│ │ Audit Log  │  │                                │  │
│ │ Settings   │  │                                │  │
│ │            │  │                                │  │
│ └────────────┘  └────────────────────────────────┘  │
│                                                      │
└─────────────────────────────────────────────────────┘
```

#### Dashboard Layout (Role-Based)

**Investigator Dashboard**
```
┌────────────────────────────────────────────────┐
│ Investigation Dashboard                        │
├────────────────────────────────────────────────┤
│                                                │
│ ┌─────────┐  ┌─────────┐  ┌─────────┐         │
│ │ Active  │  │ Pending │  │ Closed  │         │
│ │   12    │  │   5     │  │   48    │         │
│ └─────────┘  └─────────┘  └─────────┘         │
│                                                │
│ ┌── Quick Actions ──────────────────────────┐ │
│ │ [+ New Case] [Upload Evidence] [Reports] │ │
│ └──────────────────────────────────────────┘ │
│                                                │
│ ┌── My Recent Cases ────────────────────────┐ │
│ │ INV-2025-0001  Employee Fraud   S3  ●Open│ │
│ │ INV-2025-0002  Vendor Fraud     S2  ●Rev │ │
│ │ INV-2025-0003  Misconduct       S4  ●Pen │ │
│ └──────────────────────────────────────────┘ │
│                                                │
│ ┌── Cases by Status (Chart) ─────────────── │ │
│ └──────────────────────────────────────────┘ │
│                                                │
└────────────────────────────────────────────────┘
```

**Compliance Officer Dashboard**
```
┌────────────────────────────────────────────────┐
│ Compliance Decision Dashboard                  │
├────────────────────────────────────────────────┤
│                                                │
│ ┌────────────┐  ┌──────────┐  ┌────────────┐ │
│ │Pending     │  │Reportable│  │Not         │ │
│ │Decisions: 7│  │to RBI: 15│  │Reportable:│ │
│ │            │  │          │  │23          │ │
│ └────────────┘  └──────────┘  └────────────┘ │
│                                                │
│ ┌── Awaiting Decision ──────────────────────┐ │
│ │ [System Suggests: Reportable]              │ │
│ │ INV-2025-0001  ₹250K  Documentary  S3      │ │
│ │ [Decide] [View Details]                    │ │
│ │                                            │ │
│ │ [System Suggests: Not Reportable]          │ │
│ │ INV-2025-0004  ₹15K  Weak Evidence  S4    │ │
│ │ [Decide] [View Details]                    │ │
│ └──────────────────────────────────────────┘ │
│                                                │
│ ┌── Timeline Compliance ────────────────────┐ │
│ │ T+7 Due: 3 cases  T+21 Due: 1 case       │ │
│ └──────────────────────────────────────────┘ │
│                                                │
└────────────────────────────────────────────────┘
```

**Board View Dashboard**
```
┌────────────────────────────────────────────────┐
│ Board / Management View                        │
├────────────────────────────────────────────────┤
│                                                │
│ ┌── Executive Summary ──────────────────────┐ │
│ │ Total Cases YTD: 65                        │ │
│ │ Reportable Fraud: ₹12.5M                   │ │
│ │ Control Failures Identified: 8             │ │
│ │ [Download Board Pack PDF]                  │ │
│ └──────────────────────────────────────────┘ │
│                                                │
│ ┌── Fraud Trends (Last 6 Months) ──────────┐ │
│ │ [Line Chart: Case Volume & Amounts]       │ │
│ └──────────────────────────────────────────┘ │
│                                                │
│ ┌── High-Risk Cases (S1-S2) ────────────────┐ │
│ │ INV-2025-0001  ₹250K  Employee Fraud  S3  │ │
│ │ INV-2024-0089  ₹1.2M  Vendor Fraud    S2  │ │
│ └──────────────────────────────────────────┘ │
│                                                │
│ ┌── Control Environment ────────────────────┐ │
│ │ Top 3 Control Weaknesses:                  │ │
│ │ 1. Dual authorization bypass              │ │
│ │ 2. Inadequate vendor due diligence        │ │
│ │ 3. Missing transaction monitoring         │ │
│ └──────────────────────────────────────────┘ │
│                                                │
└────────────────────────────────────────────────┘
```

### 4.3 Case Management Interface

#### Case Detail View (Tabs)
```
┌────────────────────────────────────────────────────────┐
│ ← Back to Cases                                        │
│                                                        │
│ INV-2025-0001: Employee Fraud Investigation            │
│ Status: Investigation  Severity: S3  Created: Feb 1   │
├────────────────────────────────────────────────────────┤
│ [Overview] [Evidence] [Findings] [Interviews] [Review]│
│  [Compliance] [RBI Reporting] [Timeline] [Audit]      │
├────────────────────────────────────────────────────────┤
│                                                        │
│ ┌── Case Overview ────────────────────────────────┐  │
│ │                                                  │  │
│ │ Subject: John Doe (EMP12345)                     │  │
│ │ Department: Finance                              │  │
│ │ Allegation: Invoice manipulation                 │  │
│ │ Amount: ₹250,000                                 │  │
│ │                                                  │  │
│ │ Detection Date: Feb 1, 2025                      │  │
│ │ Assigned To: Sarah Investigator                  │  │
│ │                                                  │  │
│ │ ┌─ Red Flags (2) ─────────────────────────────┐ │  │
│ │ │ ⚠️ Same vendor invoices with sequential nos │ │  │
│ │ │ ⚠️ Round-amount payments without receipts   │ │  │
│ │ └──────────────────────────────────────────── │ │  │
│ │                                                  │  │
│ │ [Edit Case] [Close Case] [Generate Report]      │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
└────────────────────────────────────────────────────────┘
```

#### Evidence Vault Interface
```
┌────────────────────────────────────────────────────────┐
│ Evidence - INV-2025-0001                               │
├────────────────────────────────────────────────────────┤
│ [+ Upload Evidence] [Evidence Register ↓]             │
├────────────────────────────────────────────────────────┤
│                                                        │
│ ┌─────────────────────────────────────────────────┐  │
│ │ 🔍 Search evidence...        🗂️ [All Types ▾]   │  │
│ └─────────────────────────────────────────────────┘  │
│                                                        │
│ ┌── E1: Bank Statement ──────────────────────────┐   │
│ │ 📄 bank_statement_jan2025.pdf                   │   │
│ │ Source: Bank Portal Export                       │   │
│ │ Date: Feb 1, 2025                                │   │
│ │ Relevance: High  ✓ Verified                      │   │
│ │                                                  │   │
│ │ Linked to Findings: F1, F3                       │   │
│ │                                                  │   │
│ │ [View] [Download] [Link to Finding] [Delete]     │   │
│ └──────────────────────────────────────────────────┘   │
│                                                        │
│ ┌── E2: Email Thread ────────────────────────────┐   │
│ │ 📧 vendor_approval_emails.msg                   │   │
│ │ Source: Email System                             │   │
│ │ ...                                              │   │
│ └──────────────────────────────────────────────────┘   │
│                                                        │
└────────────────────────────────────────────────────────┘
```

#### Findings Interface
```
┌────────────────────────────────────────────────────────┐
│ Findings - INV-2025-0001                               │
├────────────────────────────────────────────────────────┤
│ [+ Add Finding]                                        │
├────────────────────────────────────────────────────────┤
│                                                        │
│ ┌── F1: Policy Violation ─────────────────────────┐  │
│ │ Category: Policy_Violation                        │  │
│ │ Risk: Critical                                    │  │
│ │                                                   │  │
│ │ Facts Established:                                │  │
│ │ • Payments approved without dual authorization    │  │
│ │ • 15 transactions identified (E1, E2, E3)        │  │
│ │ • Total value: ₹250,000                          │  │
│ │                                                   │  │
│ │ Evidence Links:                                   │  │
│ │ E1 (Bank Statement), E2 (Email Thread),          │  │
│ │ E5 (Approval Matrix Document)                     │  │
│ │                                                   │  │
│ │ ⚠️ Red Flag: Sequential invoice numbers           │  │
│ │                                                   │  │
│ │ [Edit] [Delete] [Link More Evidence]             │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
│ ┌── F2: Process Gap ──────────────────────────────┐  │
│ │ ...                                              │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
└────────────────────────────────────────────────────────┘
```

### 4.4 Compliance Decision Interface

```
┌────────────────────────────────────────────────────────┐
│ Compliance Decision - INV-2025-0001                    │
├────────────────────────────────────────────────────────┤
│                                                        │
│ ┌── System Analysis ──────────────────────────────┐  │
│ │                                                  │  │
│ │ Based on case details:                           │  │
│ │ • Severity: S3 (Medium)                          │  │
│ │ • Amount: ₹250,000                               │  │
│ │ • Evidence: Documentary (Strong)                 │  │
│ │ • Fraud Nature: Misappropriation of Funds        │  │
│ │                                                  │  │
│ │ 🤖 SYSTEM SUGGESTION:                            │  │
│ │    ✓ REPORTABLE TO RBI                           │  │
│ │                                                  │  │
│ │ Rationale:                                       │  │
│ │ • Amount exceeds ₹100K threshold                 │  │
│ │ • Documentary evidence established               │  │
│ │ • Policy violation confirmed                     │  │
│ │ • Meets RBI reporting criteria (Section 8.2.1)  │  │
│ │                                                  │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
│ ┌── Your Decision ────────────────────────────────┐  │
│ │                                                  │  │
│ │ ○ Reportable to RBI (Agree with system)          │  │
│ │ ○ Not Reportable (Override system)               │  │
│ │                                                  │  │
│ │ Decision Rationale: *                            │  │
│ │ ┌──────────────────────────────────────────────┐│  │
│ │ │ [Explain your decision...]                    ││  │
│ │ │                                               ││  │
│ │ └──────────────────────────────────────────────┘│  │
│ │                                                  │  │
│ │ [If Override] Justification: *                   │  │
│ │ ┌──────────────────────────────────────────────┐│  │
│ │ │ [Why are you overriding the system?]         ││  │
│ │ │                                               ││  │
│ │ └──────────────────────────────────────────────┘│  │
│ │                                                  │  │
│ │ [Submit Decision]                                │  │
│ │                                                  │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
│ ⚠️ Note: Override decisions are visible to CRO only   │
│                                                        │
└────────────────────────────────────────────────────────┘
```

### 4.5 Report Generation Interface

```
┌────────────────────────────────────────────────────────┐
│ Generate Investigation Report - INV-2025-0001          │
├────────────────────────────────────────────────────────┤
│                                                        │
│ ┌── Pre-Generation Checks ────────────────────────┐  │
│ │                                                  │  │
│ │ ✓ Case has findings (3 findings)                 │  │
│ │ ✓ All findings linked to evidence                │  │
│ │ ✓ Evidence vault complete (8 items)              │  │
│ │ ⚠️ Missing: Management interview statement        │  │
│ │                                                  │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
│ ┌── Report Configuration ─────────────────────────┐  │
│ │                                                  │  │
│ │ Report Type:                                     │  │
│ │ ○ Investigation Report (Standard)                │  │
│ │ ○ Board Summary Report                           │  │
│ │ ○ Management Brief                               │  │
│ │                                                  │  │
│ │ Tone: [Auto-selected: Strict] ▾                 │  │
│ │ (Based on: Fraud + S3 + Documentary Evidence)    │  │
│ │                                                  │  │
│ │ Include:                                         │  │
│ │ ☑ Evidence Register                              │  │
│ │ ☑ Interview Log                                  │  │
│ │ ☑ Action Tracker                                 │  │
│ │ ☑ Modus Operandi Section (fraud cases only)     │  │
│ │                                                  │  │
│ │ Output Format:                                   │  │
│ │ ○ Word (.docx) - Editable                        │  │
│ │ ○ PDF - Final/Locked                             │  │
│ │                                                  │  │
│ │ [Generate Report] [Preview Structure]            │  │
│ │                                                  │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
│ ┌── Report Structure Preview ─────────────────────┐  │
│ │                                                  │  │
│ │ 1. Investigation Summary                         │  │
│ │ 2. Scope & Methodology                           │  │
│ │ 3. Allegations / Issues Examined                 │  │
│ │ 4. Facts Established                             │  │
│ │ 5. Key Observations                              │  │
│ │ 6. Gaps Identified                               │  │
│ │ 7. Modus Operandi                                │  │
│ │ 8. Evidence & Testimonials                       │  │
│ │ 9. Risk & Impact Assessment                      │  │
│ │ 10. Conclusion                                   │  │
│ │ 11. Way Forward & Recommendations                │  │
│ │ 12. Disclaimer & Confidentiality                 │  │
│ │                                                  │  │
│ │ Annexures:                                       │  │
│ │ A. Evidence Register                             │  │
│ │ B. Interview Log                                 │  │
│ │ C. Action Tracker                                │  │
│ │                                                  │  │
│ └──────────────────────────────────────────────────┘  │
│                                                        │
└────────────────────────────────────────────────────────┘
```

### 4.6 Audit Trail Interface

```
┌────────────────────────────────────────────────────────┐
│ Audit Trail - INV-2025-0001                            │
├────────────────────────────────────────────────────────┤
│ 🔍 Search...  📅 [Date Range ▾]  👤 [All Users ▾]     │
├────────────────────────────────────────────────────────┤
│                                                        │
│ ┌─ Timeline View ───────────────────────────────────┐ │
│ │                                                    │ │
│ │ Feb 10, 2025 10:30 AM                              │ │
│ │ 👤 Sarah Investigator (Investigator)               │ │
│ │ 📝 Added Finding F3: Process Gap                   │ │
│ │ Details: Linked evidence E5, E6                    │ │
│ │ IP: 192.168.1.45                                   │ │
│ │                                                    │ │
│ │ ────────────────────────────────────────────────   │ │
│ │                                                    │ │
│ │ Feb 9, 2025 2:15 PM                                │ │
│ │ 👤 Mike Compliance (Compliance Officer)            │ │
│ │ ⚠️ OVERRIDE: Decision marked as Not Reportable     │ │
│ │ System Suggested: Reportable                       │ │
│ │ Justification: "Amount below materiality threshold"│ │
│ │ Visibility: CRO Only                               │ │
│ │ IP: 192.168.1.78                                   │ │
│ │                                                    │ │
│ │ ────────────────────────────────────────────────   │ │
│ │                                                    │ │
│ │ Feb 8, 2025 11:00 AM                               │ │
│ │ 👤 Rita RCU (RCU Reviewer)                         │ │
│ │ ✓ Review Submitted                                 │ │
│ │ Recommendation: Report to RBI                      │ │
│ │ All findings validated                             │ │
│ │                                                    │ │
│ │ ────────────────────────────────────────────────   │ │
│ │                                                    │ │
│ │ Feb 5, 2025 4:45 PM                                │ │
│ │ 👤 Sarah Investigator                              │ │
│ │ 📎 Uploaded Evidence E1: bank_statement.pdf        │ │
│ │ Hash: a3f5d8e9...                                  │ │
│ │                                                    │ │
│ └────────────────────────────────────────────────────┘ │
│                                                        │
│ [Export Audit Trail PDF] [Filter by Action Type]      │
│                                                        │
└────────────────────────────────────────────────────────┘
```

---

## 5. KEY FEATURES & INTERACTIONS

### 5.1 Evidence-to-Finding Linking

**User Flow:**
1. Investigator creates a finding
2. System prompts: "Link evidence to support this finding"
3. Modal shows available evidence with checkboxes
4. Investigator selects relevant evidence
5. System validates: At least one piece of evidence required
6. Confirmation message: "Finding F1 linked to Evidence E1, E2, E5"

**Visual Indicator:**
- Findings without evidence show ⚠️ warning badge
- Evidence linked to findings show 🔗 icon with count
- Hover shows quick preview of links

### 5.2 Compliance Override Tracking

**User Flow:**
1. System analyzes case and suggests decision
2. Compliance officer sees suggestion with rationale
3. If agreeing: Simple confirmation, no justification needed
4. If overriding: Must provide detailed justification
5. System flags as override and restricts visibility
6. CRO dashboard shows all overrides for review

**Visual Design:**
```
┌────────────────────────────────────────────┐
│ 🤖 System Suggestion: Reportable          │
│                                            │
│ Your Decision:                             │
│ ○ Agree with system                        │
│ ● Override (Not Reportable) ← Selected    │
│                                            │
│ ⚠️ Override Justification Required         │
│ ┌──────────────────────────────────────┐  │
│ │ [Detailed explanation required...]    │  │
│ │                                       │  │
│ │                                       │  │
│ └──────────────────────────────────────┘  │
│                                            │
│ ℹ️ This override will be visible only to: │
│    • Chief Risk Officer (CRO)              │
│    • Internal Audit Team                   │
│                                            │
│ [Cancel] [Submit Override Decision]        │
└────────────────────────────────────────────┘
```

### 5.3 S4 Case Special Handling

**Triggers:**
- When Compliance Officer marks S4 case as Reportable
- System immediately blocks submission
- Displays: "S4 cases require CRO approval before reporting"

**CRO Approval Flow:**
```
┌────────────────────────────────────────────┐
│ ⚠️ S4 Case Pending Your Approval           │
│                                            │
│ INV-2025-0001                              │
│ Compliance Decision: Reportable to RBI     │
│ Amount: ₹250,000                           │
│                                            │
│ Compliance Rationale:                      │
│ "Despite S4 classification, documentary    │
│  evidence is strong and amount material."  │
│                                            │
│ Your Decision:                             │
│ ○ Approve Reporting                        │
│ ○ Send Back for Review                     │
│                                            │
│ ☐ Also notify CEO                          │
│                                            │
│ [Approve] [Send Back]                      │
└────────────────────────────────────────────┘
```

### 5.4 Timeline Compliance Tracking

**Visual Indicator:**
```
┌────────────────────────────────────────────┐
│ RBI Reporting Timeline                     │
│                                            │
│ Detection Date: Feb 1, 2025                │
│                                            │
│ ┌───────────────┐  ┌──────────────────┐  │
│ │ T+7           │  │ T+21             │  │
│ │ Due: Feb 8    │  │ Due: Feb 22      │  │
│ │ Status: ⏱️On   │  │ Status: ✓ Ahead  │  │
│ │         Time  │  │                  │  │
│ └───────────────┘  └──────────────────┘  │
│                                            │
│ Progress: [████████░░] 80% complete       │
│                                            │
│ Next Milestone: Submit FMR-1 by Feb 8     │
│                                            │
└────────────────────────────────────────────┘
```

### 5.5 Board Narrative Auto-Generation

**AI-Assisted Generation:**
1. User clicks "Generate Board Narrative"
2. System pulls:
   - Case summary
   - Key findings
   - Financial impact
   - Control gaps
3. Claude generates executive-level narrative
4. User reviews and edits
5. Added to Board Pack

**Example Output:**
```
BOARD NARRATIVE - JANUARY 2025 FRAUD OVERVIEW

During January 2025, the organization identified 5 
potential fraud cases totaling ₹3.2M in exposure.

KEY CASES:
• Employee fraud (INV-2025-0001): ₹250K invoice 
  manipulation scheme involving vendor collusion

CONTROL ENVIRONMENT:
Primary control weakness identified: Dual 
authorization bypass in vendor payment system

ACTIONS TAKEN:
• Immediate process enhancement initiated
• Subject suspended pending investigation completion
• System access revoked

RBI REPORTING:
2 cases classified as reportable; FMR-1 submissions 
completed within mandated timelines
```

---

## 6. SECURITY & COMPLIANCE

### 6.1 Authentication & Authorization

**JWT Token Strategy:**
```javascript
// Token structure
{
  "user_id": "uuid",
  "email": "user@example.com",
  "role": "Investigator",
  "permissions": ["create_case", "upload_evidence", ...],
  "exp": 1234567890, // 15 min for access token
  "iat": 1234567000
}

// Refresh token (httpOnly cookie, 7 days)
// Stored in database with revocation capability
```

**Role-Based Access Control (RBAC):**
| Role | Permissions |
|------|-------------|
| **Investigator** | Create/edit cases, upload evidence, create findings, generate reports |
| **RCU Reviewer** | View cases, validate findings, submit review recommendations |
| **Compliance Officer** | View all cases, make reportability decisions, override system |
| **CRO** | View all cases + overrides, approve S4 decisions, CEO notification |
| **Internal Audit** | Read-only access to all data including overrides |
| **Board** | Read-only dashboard, download board packs |

### 6.2 Data Security

**Encryption:**
- At rest: PostgreSQL native encryption
- In transit: TLS 1.3
- File storage: Server-side encryption (S3 SSE-KMS)
- Password hashing: bcrypt with cost factor 12

**File Integrity:**
- SHA-256 hash calculated on upload
- Hash stored in database
- Verification on download
- Tamper detection

**Audit Logging:**
- Every data modification logged
- User context captured (ID, role, IP)
- Before/after values for changes
- Immutable audit trail
- Retention: 7 years (regulatory compliance)

### 6.3 Data Retention & Deletion

**Retention Policy:**
- Active cases: Indefinite
- Closed cases: 7 years (RBI requirement)
- Audit logs: 7 years
- User data: Active + 1 year post-termination

**Soft Delete:**
- Cases marked as deleted, not physically removed
- Deleted data invisible to users
- CRO can restore within 90 days
- Permanent deletion after retention period

---

## 7. AI INTEGRATION ARCHITECTURE

### 7.1 Claude API Integration

**Service Layer:**
```python
# app/services/ai_service.py

class ClaudeAIService:
    def __init__(self):
        self.client = anthropic.Anthropic(
            api_key=settings.ANTHROPIC_API_KEY
        )
        self.model = "claude-sonnet-4-5-20250929"
    
    async def generate_investigation_report(
        self,
        case: Case,
        findings: List[Finding],
        evidence: List[Evidence],
        interviews: List[Interview],
        tone: str
    ) -> str:
        """Generate investigation report using Claude"""
        
        # Build structured context
        context = self._build_report_context(
            case, findings, evidence, interviews
        )
        
        # Load tone rules
        tone_rules = self._get_tone_rules(case, tone)
        
        # Generate report
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=8000,
            temperature=0.3,  # Lower temp for consistency
            system=self._get_system_prompt(tone_rules),
            messages=[{
                "role": "user",
                "content": f"Generate investigation report:\n\n{context}"
            }]
        )
        
        return response.content[0].text
    
    def _get_system_prompt(self, tone_rules: dict) -> str:
        """Load system prompt with tone rules"""
        return f"""
        You are an expert investigation report writer for 
        financial institutions in India.
        
        CRITICAL RULES:
        - Tone: {tone_rules['tone']}
        - Never attribute intent without proof
        - Use cautious language where evidence is weak
        - Reference evidence by ID (E1, E2, etc.)
        - Stick to fixed report structure
        - No sections can be added or removed
        
        PROHIBITED LANGUAGE:
        {', '.join(tone_rules['prohibited_phrases'])}
        
        REQUIRED CAUTIONARY PHRASES:
        {', '.join(tone_rules['required_phrases'])}
        """
```

### 7.2 AI-Assisted Features

**1. Report Draft Generation**
- Input: Case + Findings + Evidence + Interviews
- Output: Full Word document
- Processing time: ~20-30 seconds
- Queue: Celery background task

**2. Finding Suggestions**
- Input: Evidence summary
- Output: Potential findings with risk ratings
- User validates before accepting

**3. Fraud Classification**
- Input: Case details + Modus operandi
- Output: RBI taxonomy classification suggestions
- Compliance officer makes final decision

**4. Board Narrative Generation**
- Input: Multiple cases (monthly summary)
- Output: Executive-level summary
- CRO reviews and approves

**5. Evidence Summarization**
- Input: Long documents (emails, statements)
- Output: Key facts extracted
- Helps investigators quickly assess relevance

### 7.3 AI Safety & Governance

**Human-in-the-Loop:**
- AI generates drafts, never final decisions
- All AI outputs marked as "AI-Generated - Requires Review"
- User must explicitly approve before use

**Output Validation:**
```python
class AIOutputValidator:
    """Validate AI-generated content"""
    
    def validate_report(self, report: str, case: Case) -> ValidationResult:
        """Check report against quality rules"""
        errors = []
        warnings = []
        
        # Check for required sections
        required_sections = [
            "Investigation Summary",
            "Facts Established",
            "Evidence & Testimonials",
            "Conclusion"
        ]
        for section in required_sections:
            if section not in report:
                errors.append(f"Missing required section: {section}")
        
        # Check for prohibited language
        prohibited = ["definitely", "certainly", "proves guilt"]
        for word in prohibited:
            if word.lower() in report.lower():
                warnings.append(f"Risky language detected: {word}")
        
        # Check evidence references
        evidence_ids = [f"E{i}" for i in range(1, case.evidence_count + 1)]
        if not any(eid in report for eid in evidence_ids):
            errors.append("No evidence references found in report")
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings
        )
```

**Data Privacy:**
- No AI training on customer data (Anthropic's commitment)
- Data residency: India/EU regions only
- Audit trail for all AI generations

---

## 8. PERFORMANCE & SCALABILITY

### 8.1 Performance Targets

| Metric | Target | Measurement |
|--------|--------|-------------|
| Page Load Time | < 2 seconds | Time to interactive |
| API Response Time | < 500ms | 95th percentile |
| Report Generation | < 30 seconds | AI processing + rendering |
| File Upload | < 5 seconds | For 10MB files |
| Database Queries | < 100ms | 95th percentile |
| Concurrent Users | 100+ | Without degradation |

### 8.2 Caching Strategy

**Frontend Caching:**
- Static assets: CDN caching (1 year)
- API responses: React Query cache (5 minutes)
- Images: Browser cache + CDN

**Backend Caching:**
- Redis for:
  - User sessions
  - Dashboard statistics (5 min TTL)
  - Report templates (1 hour TTL)
  - Frequent queries

**Database Optimization:**
- Indexes on all foreign keys
- Partial indexes for status/severity
- Full-text search with GIN indexes
- Query optimization with EXPLAIN ANALYZE

### 8.3 Scalability Considerations

**Horizontal Scaling:**
- Stateless backend (can run multiple instances)
- Load balancer distribution
- Database connection pooling
- Background task distribution (Celery workers)

**Vertical Scaling:**
- Database: Neon autoscaling
- Backend: Resource-based scaling on Railway/Render
- File storage: S3 (infinite scale)

**Limits:**
- Max file size: 50MB per upload
- Max evidence per case: 100
- Max findings per case: 50
- Report generation queue: 10 concurrent

---

## 9. UAT (OFFLINE MODE) ARCHITECTURE

### 9.1 Offline Capabilities

**Requirements:**
- Runnable on laptop without internet
- Pre-seeded test data
- All features functional
- Clear "UAT Mode" indicators

**Implementation:**
```python
# config.py
class Settings:
    UAT_MODE: bool = os.getenv("UAT_MODE", "false").lower() == "true"
    
    if UAT_MODE:
        # Use SQLite instead of PostgreSQL
        DATABASE_URL = "sqlite:///./tahakikat_uat.db"
        
        # Use dummy AI service (no API calls)
        AI_SERVICE = "mock"
        
        # Use local file storage
        FILE_STORAGE = "local"
```

**Mock AI Service:**
```python
class MockAIService:
    """Simulate AI responses for UAT"""
    
    def generate_investigation_report(self, *args) -> str:
        return """
        [UAT MODE - MOCK REPORT]
        
        This is a simulated investigation report generated
        in UAT mode. In production, this would be generated
        by Claude AI.
        
        1. Investigation Summary
        ...
        """
    
    def suggest_findings(self, *args) -> List[Finding]:
        return [
            Finding(
                title="[UAT] Sample Finding 1",
                description="Mock finding for testing",
                category="Policy_Violation"
            )
        ]
```

### 9.2 Test Data Seeding

**Seed Script:**
```python
# scripts/seed_uat_data.py

def seed_uat_database():
    """Populate database with realistic test data"""
    
    # Create test users
    users = [
        User(email="investigator@test.com", role="Investigator"),
        User(email="rcu@test.com", role="RCU_Reviewer"),
        User(email="compliance@test.com", role="Compliance_Officer"),
        User(email="cro@test.com", role="CRO"),
    ]
    
    # Create test cases
    cases = [
        Case(
            case_number="INV-2025-TEST-001",
            case_type="Employee_Fraud",
            severity="S3",
            subject_name="Test Subject A",
            allegation_summary="Test allegation",
            amount_involved=250000.00,
            status="Investigation"
        ),
        # ... more test cases
    ]
    
    # Create evidence, findings, etc.
    ...
```

### 9.3 UAT Marking System

**Visual Indicators:**
```css
/* UAT Mode Banner */
.uat-banner {
  position: fixed;
  top: 0;
  width: 100%;
  background: #f59e0b;
  color: white;
  padding: 8px;
  text-align: center;
  font-weight: bold;
  z-index: 9999;
}

.uat-banner::before {
  content: "⚠️ UAT MODE - Test Environment ";
}
```

**Mock Data Labels:**
- All test cases prefixed with "TEST-"
- Fake names: "Test Subject A", "Test Vendor B"
- Clear "This is sample data" watermarks

---

## 10. DEPLOYMENT ARCHITECTURE

### 10.1 Deployment Strategy

**Development Environment:**
```
Developer Laptop (Deepak)
├── Frontend: localhost:5173 (Vite dev server)
├── Backend: localhost:8000 (Uvicorn)
└── Database: Neon (shared dev instance)
```

**Production Environment:**
```
┌─────────────────────────────────────────┐
│ FRONTEND (Vercel)                       │
│ - React app                             │
│ - CDN distribution                      │
│ - Auto SSL                              │
└──────────────┬──────────────────────────┘
               │
               ├──> API Gateway
               │
┌──────────────┴──────────────────────────┐
│ BACKEND (Railway/Render)                │
│ - FastAPI app                           │
│ - Background workers (Celery)           │
│ - Auto-scaling                          │
└──────────────┬──────────────────────────┘
               │
               ├──> Database (Neon)
               │
               ├──> File Storage (S3)
               │
               └──> Cache (Redis)
```

### 10.2 CI/CD Pipeline

**GitHub Actions Workflow:**
```yaml
# .github/workflows/deploy.yml

name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run Python tests
        run: |
          cd backend
          pip install -r requirements.txt
          pytest
  
  test-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run React tests
        run: |
          cd frontend
          npm install
          npm test
  
  deploy-backend:
    needs: [test-backend]
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to Railway
        uses: railway/deploy@v1
        with:
          api-key: ${{ secrets.RAILWAY_TOKEN }}
  
  deploy-frontend:
    needs: [test-frontend]
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to Vercel
        uses: vercel/deploy@v1
        with:
          token: ${{ secrets.VERCEL_TOKEN }}
```

### 10.3 Environment Variables

**Backend (.env):**
```bash
# Database
DATABASE_URL=postgresql://...

# AI
ANTHROPIC_API_KEY=sk-ant-...

# File Storage
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
S3_BUCKET_NAME=tahakikat-evidence

# Security
JWT_SECRET_KEY=...
JWT_REFRESH_SECRET_KEY=...

# Redis
REDIS_URL=redis://...

# Mode
ENVIRONMENT=production
DEBUG=false
```

**Frontend (.env.production):**
```bash
VITE_API_BASE_URL=https://api.tahakikat.com
VITE_ENVIRONMENT=production
```

---

## 11. MONITORING & OBSERVABILITY

### 11.1 Error Tracking

**Sentry Integration:**
```python
# app/main.py
import sentry_sdk

sentry_sdk.init(
    dsn=settings.SENTRY_DSN,
    environment=settings.ENVIRONMENT,
    traces_sample_rate=0.1,
)

@app.middleware("http")
async def sentry_context(request: Request, call_next):
    with sentry_sdk.configure_scope() as scope:
        scope.set_user({
            "id": request.state.user_id,
            "email": request.state.user_email
        })
    return await call_next(request)
```

### 11.2 Application Metrics

**Key Metrics to Track:**
- Case creation rate
- Report generation time
- API response times
- Error rates
- User active sessions
- Storage usage
- AI API costs

**Dashboard Tools:**
- Railway/Render built-in metrics
- PostHog for analytics
- Custom Grafana dashboard (optional)

### 11.3 Logging Strategy

**Structured Logging:**
```python
import structlog

logger = structlog.get_logger()

# Usage
logger.info(
    "case_created",
    case_id=case.id,
    case_number=case.case_number,
    user_id=current_user.id,
    severity=case.severity
)
```

**Log Levels:**
- DEBUG: Development only
- INFO: Normal operations (case created, report generated)
- WARNING: Validation failures, API retries
- ERROR: Exceptions, failed operations
- CRITICAL: System failures, security issues

---

## 12. TESTING STRATEGY

### 12.1 Backend Testing

**Test Structure:**
```
backend/tests/
├── unit/
│   ├── test_models.py
│   ├── test_services.py
│   └── test_utils.py
├── integration/
│   ├── test_api_cases.py
│   ├── test_api_evidence.py
│   └── test_report_generation.py
└── e2e/
    └── test_case_lifecycle.py
```

**Example Test:**
```python
# tests/integration/test_api_cases.py

async def test_create_case(client, auth_headers):
    """Test case creation API"""
    response = await client.post(
        "/api/v1/cases/",
        json={
            "case_type": "Employee_Fraud",
            "severity": "S3",
            "subject_name": "Test Subject",
            "allegation_summary": "Test allegation",
            "detection_date": "2025-02-01"
        },
        headers=auth_headers
    )
    
    assert response.status_code == 201
    data = response.json()
    assert data["case_number"].startswith("INV-2025-")
    assert data["status"] == "Draft"
```

### 12.2 Frontend Testing

**Test Structure:**
```
frontend/src/__tests__/
├── components/
│   ├── CaseCard.test.tsx
│   └── EvidenceUpload.test.tsx
├── pages/
│   ├── Dashboard.test.tsx
│   └── CaseDetail.test.tsx
└── integration/
    └── case-creation-flow.test.tsx
```

**Tools:**
- Jest + React Testing Library
- Cypress for E2E tests

### 12.3 UAT Test Scenarios

**Critical User Journeys:**
1. ✅ Create case → Add evidence → Add findings → Link evidence to findings → Generate report
2. ✅ Investigator creates case → RCU reviews → Compliance decides → RBI report generated
3. ✅ Compliance overrides system → CRO sees override → Approves/rejects
4. ✅ S4 case marked reportable → CRO approval required → CEO notified
5. ✅ Audit trail captures all actions → Searchable → Exportable

---

## 13. MAINTENANCE & SUPPORT

### 13.1 Documentation

**Developer Documentation:**
- API documentation (auto-generated Swagger)
- Architecture decision records (ADRs)
- Database schema diagrams
- Deployment runbooks

**User Documentation:**
- User manual (role-based)
- Video tutorials for each workflow
- FAQ
- Troubleshooting guide

### 13.2 Backup & Recovery

**Database Backups:**
- Neon automated daily backups (7-day retention)
- Manual backup before major changes
- Restore testing quarterly

**File Backups:**
- S3 versioning enabled
- Cross-region replication (disaster recovery)

**Recovery Time Objective (RTO):** < 4 hours
**Recovery Point Objective (RPO):** < 24 hours

### 13.3 Support Tiers

**Tier 1 - Self-Service:**
- Documentation
- FAQ
- Video tutorials

**Tier 2 - Email Support:**
- Response time: 24 hours
- Handle: Configuration issues, how-to questions

**Tier 3 - Phone/Video Support:**
- Response time: 4 hours (business hours)
- Handle: Critical bugs, system outages

---

## 14. COST ESTIMATION

### 14.1 Recurring Costs (Monthly)

| Service | Tier | Cost |
|---------|------|------|
| Neon (Database) | Scale plan | $19/month |
| Railway (Backend) | Starter | $20/month |
| Vercel (Frontend) | Pro | $20/month |
| AWS S3 (Storage) | Pay-as-you-go | ~$5/month |
| Redis Cloud | Free tier | $0 |
| Anthropic API | Usage-based | ~$50-100/month* |
| Sentry (Monitoring) | Developer | $26/month |
| **TOTAL** | | **~$140-170/month** |

*Based on ~1000 reports/month. Adjust based on actual usage.

### 14.2 One-Time Costs

- Domain name: ~$15/year
- SSL certificate: Free (Let's Encrypt)
- Logo/branding: Variable
- Initial UAT: Included in dev time

---

## 15. FUTURE ENHANCEMENTS (Phase 2+)

### Phase 2 (6-12 months)
- Multi-tenancy (multiple organizations)
- Advanced analytics dashboards
- Email notifications
- Mobile app (React Native)
- Bulk operations (batch case creation)

### Phase 3 (12+ months)
- Integration with core banking systems
- Automated fraud detection rules
- Machine learning for pattern recognition
- Whistleblower portal
- Multi-language support

---

## APPENDIX A: GLOSSARY

**S1-S4:** Severity ratings (S1 = Critical, S4 = Low)
**RBI:** Reserve Bank of India
**FMR:** Fraud Monitoring Return (RBI reports)
**RCU:** Risk & Compliance Unit
**CRO:** Chief Risk Officer
**T+7/T+21:** Timeline requirements (days after detection)
**UAT:** User Acceptance Testing
**PRD:** Product Requirements Document

---

**END OF TECHNICAL ARCHITECTURE DOCUMENT**

---

*This document is a living specification. Updates should be versioned and approved by the product owner.*

*Last Updated: February 10, 2025*
*Version: 1.0*
*Prepared by: Claude (Anthropic AI)*
*For: Deepak's Investigation Platform Project*
